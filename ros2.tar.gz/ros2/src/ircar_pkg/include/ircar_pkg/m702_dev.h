#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <stdint.h>
#include <errno.h>

#define FRAME_SIZE 17
#define FRAME_HEADER1 0x3C
#define FRAME_HEADER2 0x02

#define BAUDRATE B9600
#define SERIAL_DEVICE "/dev/airsens"


class M702_DEV {
public:
    uint16_t eco2;      // CO₂浓度 (ppm)
    uint16_t ech2o;     // 甲醛浓度 (ppb)
    uint16_t tvoc;      // TVOC浓度 (ppb)
    uint16_t pm25;      // PM2.5浓度 (μg/m³)
    uint16_t pm10;      // PM10浓度 (μg/m³)
    float temperature;  // 温度 (℃)
    float humidity;     // 湿度 (%RH)

    int m702_fd;

    int open_dev(const char *dev = SERIAL_DEVICE, int baudrate = BAUDRATE);
    int close_dev(int fd);
    int parse_m702_frame(uint8_t *buf, M702_DEV *data);
    int read_m702_data(int fd, M702_DEV *data);
};



