#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <iostream>


#define SERIAL_PORT "/dev/ttyS3"  // 串口设备路径
#define BAUD_RATE B115200  // 波特率
#define TIMEOUT 0  // 超时时间，单位为秒


// 串口通信结构体
typedef struct {
    const char *port;
    speed_t baud_rate;
    int timeout;
    int fd;  // 串口文件描述符
} SerialComm;


int get_baud_rate(speed_t baud_rate);
int open_serial(SerialComm *serial);
int send_data(SerialComm *serial, char data);
void close_serial(SerialComm *serial);
int send_strdata(SerialComm *serial, const char* data);