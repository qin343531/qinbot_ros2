#include "m702_dev.h"


int M702_DEV::open_dev(const char *dev, int baudrate) 
{
    int fd = open(dev, O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1) {
        perror("open failed");
        return -1;
    }

    struct termios tty;
    if (tcgetattr(fd, &tty) != 0) {
        perror("tcgetattr failed");
        close(fd);
        return -1;
    }

    cfsetospeed(&tty, baudrate);
    cfsetispeed(&tty, baudrate);

    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
    tty.c_cflag &= ~(PARENB | PARODD);
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CRTSCTS;
    tty.c_cflag |= (CLOCAL | CREAD);

    tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    tty.c_oflag &= ~OPOST;

    tty.c_cc[VMIN]  = 0;
    tty.c_cc[VTIME] = 10;

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        perror("tcsetattr failed");
        close(fd);
        return -1;
    }

    return fd;
}


int M702_DEV::parse_m702_frame(uint8_t *buf, M702_DEV *data)
{
    if (buf[0] != FRAME_HEADER1 || buf[1] != FRAME_HEADER2) {
        return -1;
    }

    uint8_t checksum = 0;
    for (int i = 0; i < 16; i++) {
        checksum += buf[i];
    }
    if ((checksum & 0xFF) != buf[16]) {
        return -2;
    }

    data->eco2 = (buf[2] << 8) | buf[3];
    data->ech2o = (buf[4] << 8) | buf[5];
    data->tvoc = (buf[6] << 8) | buf[7];
    data->pm25 = (buf[8] << 8) | buf[9];
    data->pm10 = (buf[10] << 8) | buf[11];

    uint8_t temp_int = buf[12];
    uint8_t temp_dec = buf[13];
    if (temp_int & 0x80) {
        data->temperature = -((temp_int & 0x7F) + temp_dec / 100.0f);
    } else {
        data->temperature = (temp_int + temp_dec / 100.0f);
    }

    uint8_t hum_int = buf[14];
    uint8_t hum_dec = buf[15];
    data->humidity = hum_int + hum_dec / 100.0f;

    return 0;
}

int M702_DEV::close_dev(int fd) 
{
    return close(fd);
}


int M702_DEV::read_m702_data(int fd, M702_DEV *data) {
    // 临时缓存有效数据，避免重复发布
    static bool has_valid = false;
    static uint16_t cache_eco2 = 0;
    static uint16_t cache_ech2o = 0;
    static uint16_t cache_tvoc = 0;
    static uint16_t cache_pm25 = 0;
    static uint16_t cache_pm10 = 0;
    static float cache_temp = 0.0f;
    static float cache_humi = 0.0f;

    if (fd < 0) {
        return -3; // 串口未打开，不打印日志
    }

    uint8_t frame_buf[FRAME_SIZE] = {0};
    ssize_t read_bytes = read(fd, frame_buf, FRAME_SIZE);

    // 1. 处理EAGAIN（资源临时不可用）：直接返回，不报错
    if (read_bytes < 0) {
        if (errno == EAGAIN) {
            return -5; // 超时无数据，不打印、不复用旧数据
        }
        perror("read failed");
        return -1;
    }

    // 2. 帧不完整：直接返回
    if (read_bytes != FRAME_SIZE) {
        return -4;
    }

    // 3. 解析帧数据
    int ret = parse_m702_frame(frame_buf, data);
    if (ret != 0) {
        return ret; // 帧头/校验和错误，不打印
    }

    // 4. 过滤无效数据
    if (data->eco2 == 0 && data->ech2o == 0 && data->tvoc == 0 && data->temperature == 0.0f) {
        return -6;
    }

    // 5. 更新缓存 + 标记有效
    cache_eco2 = data->eco2;
    cache_ech2o = data->ech2o;
    cache_tvoc = data->tvoc;
    cache_pm25 = data->pm25;
    cache_pm10 = data->pm10;
    cache_temp = data->temperature;
    cache_humi = data->humidity;
    has_valid = true;

    // 6. 打印有效数据（可选）
    // printf("CO₂: %u ppm\n", data->eco2);
    // printf("甲醛: %u ppb\n", data->ech2o);
    // printf("TVOC: %u ppb\n", data->tvoc);
    // printf("PM2.5: %u μg/m³\n", data->pm25);
    // printf("PM10: %u μg/m³\n", data->pm10);
    // printf("温度: %.2f ℃\n", data->temperature);
    // printf("湿度: %.2f %%RH\n", data->humidity);
    // printf("------------------------\n");

    return 0; // 仅解析成功返回0
}