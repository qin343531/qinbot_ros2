#include <iostream>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <opencv2/opencv.hpp>
#include <thread>
#include <string>
#include <vector>
#include <chrono>
#include <cerrno>
#include <fcntl.h>
#include <termios.h>
#include <cstdint>

// 包含你的M702_DEV头文件
#include "m702_dev.h"

// ========== 常量定义 ==========
#define SERVER_IP "192.168.1.15"   // 服务器 IP 地址
#define BUFFER_SIZE 1024          // 缓冲区大小
#define VIDEO_PORT 12345           // 视频流端口
#define MESSAGE_PORT 12346         // 传感器数据端口

// 创建m702传感器对象（来自你的头文件定义）
M702_DEV m702_dev;

// ========== 视频TCP客户端类 ==========
class Video_TcpClient {
public:
    Video_TcpClient(const std::string& serverIp, int serverPort)
        : serverIp(serverIp), serverPort(serverPort), sockfd(-1), isRunning(false) {}

    ~Video_TcpClient() {
        stop();
        if (sockfd != -1) {
            close(sockfd);
            std::cout << "视频客户端socket已关闭" << std::endl;
        }
    }

    bool connectToServer() {
        // 创建套接字
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd == -1) {
            std::cerr << "创建视频套接字失败: " << strerror(errno) << std::endl;
            return false;
        }

        // 设置服务器地址
        struct sockaddr_in serverAddr;
        memset(&serverAddr, 0, sizeof(serverAddr));
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(serverPort);
        if (inet_pton(AF_INET, serverIp.c_str(), &serverAddr.sin_addr) <= 0) {
            std::cerr << "无效的服务器IP地址" << std::endl;
            close(sockfd);
            sockfd = -1;
            return false;
        }

        // 连接到服务器
        if (connect(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
            std::cerr << "Video连接服务器失败: " << strerror(errno) << std::endl;
            close(sockfd);
            sockfd = -1;
            return false;
        }

        isRunning = true;
        std::cout << "成功连接到视频服务器 " << serverIp << ":" << serverPort << std::endl;
        return true;
    }

    void sendVideoStream() {
        if (!isRunning || sockfd == -1) {
            std::cerr << "未连接到服务器，无法发送视频流" << std::endl;
            return;
        }

        // 使用 OpenCV 打开视频流
        cv::VideoCapture cap("/dev/video9", cv::CAP_V4L2); 
        if (!cap.isOpened()) {
            std::cerr << "打开视频设备失败: " << strerror(errno) << std::endl;
            isRunning = false;
            return;
        }

        // 设置分辨率
        cap.set(cv::CAP_PROP_FRAME_WIDTH, 640);
        cap.set(cv::CAP_PROP_FRAME_HEIGHT, 480);
        cap.set(cv::CAP_PROP_FPS, 30);

        std::cout << "视频设备已打开，分辨率: " 
                  << cap.get(cv::CAP_PROP_FRAME_WIDTH) << "x" 
                  << cap.get(cv::CAP_PROP_FRAME_HEIGHT) << std::endl;

        cv::Mat frame, resized;
        while (isRunning) {
            cap >> frame;
            if (frame.empty()) {
                std::cerr << "读取视频帧失败" << std::endl;
                break;
            }

            // 调整分辨率
            cv::resize(frame, resized, cv::Size(640, 480)); 

            // 编码为JPEG
            std::vector<int> encodeParams = {cv::IMWRITE_JPEG_QUALITY, 80};
            std::vector<uchar> buffer;
            if (!cv::imencode(".jpg", resized, buffer, encodeParams)) {
                std::cerr << "编码视频帧失败" << std::endl;
                continue;
            }

            // 发送帧大小
            uint64_t imageSize = buffer.size();
            ssize_t sent = send(sockfd, &imageSize, sizeof(imageSize), 0);
            if (sent != sizeof(imageSize)) {
                std::cerr << "发送图像大小失败: " << strerror(errno) << std::endl;
                break;
            }

            // 分片发送图像数据
            size_t totalSent = 0;
            while (totalSent < buffer.size() && isRunning) {
                sent = send(sockfd, buffer.data() + totalSent, buffer.size() - totalSent, 0);
                if (sent <= 0) {
                    std::cerr << "发送图像数据失败: " << strerror(errno) << std::endl;
                    break;
                }
                totalSent += sent;
            }

            if (totalSent != buffer.size()) break;

            // 控制帧率
            std::this_thread::sleep_for(std::chrono::milliseconds(33));
        }

        cap.release();
        isRunning = false;
        std::cout << "视频流发送结束" << std::endl;
    }

    void stop() {
        isRunning = false;
    }

    // 公共访问函数（供外部判断运行状态）
    bool isClientRunning() const {
        return isRunning;
    }

private:
    std::string serverIp;
    int serverPort;
    int sockfd;
    bool isRunning;
};

// ========== 消息TCP客户端类 ==========
class Message_TcpClient {
public:
    Message_TcpClient(const std::string& serverIp, int serverPort)
        : serverIp(serverIp), serverPort(serverPort), sockfd(-1), isRunning(false) {}

    ~Message_TcpClient() {
        stop();
        if (sockfd != -1) {
            close(sockfd);
            std::cout << "消息客户端socket已关闭" << std::endl;
        }
    }

    bool connectToServer() {
        // 创建套接字
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd == -1) {
            std::cerr << "创建消息套接字失败: " << strerror(errno) << std::endl;
            return false;
        }

        // 设置服务器地址
        struct sockaddr_in serverAddr;
        memset(&serverAddr, 0, sizeof(serverAddr));
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(serverPort);
        if (inet_pton(AF_INET, serverIp.c_str(), &serverAddr.sin_addr) <= 0) {
            std::cerr << "无效的服务器IP地址" << std::endl;
            close(sockfd);
            sockfd = -1;
            return false;
        }

        // 连接到服务器
        if (connect(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
            std::cerr << "Message连接服务器失败: " << strerror(errno) << std::endl;
            close(sockfd);
            sockfd = -1;
            return false;
        }

        isRunning = true;
        std::cout << "成功连接到消息服务器 " << serverIp << ":" << serverPort << std::endl;
        return true;
    }

    void sendMessage(const std::string& message) {
        if (!isRunning || sockfd == -1) {
            std::cerr << "未连接到服务器，无法发送消息" << std::endl;
            return;
        }

        ssize_t sent = send(sockfd, message.c_str(), message.size(), 0);
        if (sent != (ssize_t)message.size()) {
            std::cerr << "发送消息失败: " << strerror(errno) << std::endl;
            isRunning = false;
        } else {
            std::cout << "发送消息: " << message << std::endl;
        }
    }

    std::string receiveMessage() {
        if (!isRunning || sockfd == -1) return "";

        char buffer[BUFFER_SIZE] = {0};
        int bytesRead = recv(sockfd, buffer, sizeof(buffer) - 1, 0);
        if (bytesRead > 0) {
            buffer[bytesRead] = '\0';
            return std::string(buffer);
        } else if (bytesRead == 0) {
            std::cerr << "消息服务器连接关闭" << std::endl;
            isRunning = false;
        } else {
            std::cerr << "接收消息失败: " << strerror(errno) << std::endl;
        }
        return "";
    }

    void stop() {
        isRunning = false;
    }

    // 公共访问函数（供外部判断运行状态）
    bool isClientRunning() const {
        return isRunning;
    }

private:
    std::string serverIp;
    int serverPort;
    int sockfd;
    bool isRunning;
};

// ========== 主函数 ==========
int main() {
    // 1. 创建客户端对象
    Video_TcpClient video_client(SERVER_IP, VIDEO_PORT);
    Message_TcpClient message_client(SERVER_IP, MESSAGE_PORT);

    // 2. 连接服务器
    if (!video_client.connectToServer() || !message_client.connectToServer()) {
        std::cerr << "服务器连接失败，程序退出" << std::endl;
        return -1;
    }

    // 3. 打开串口（使用你定义的open_dev函数）
    m702_dev.m702_fd = m702_dev.open_dev(SERIAL_DEVICE, BAUDRATE);
    if (m702_dev.m702_fd < 0) {
        std::cerr << "无法打开串口设备，程序退出" << std::endl;
        return -1;
    }

    // 4. 启动视频发送线程
    std::thread videoThread([&video_client]() {
        video_client.sendVideoStream();
    });

    // 5. 启动传感器数据发送线程（适配你的read_m702_data逻辑）
    std::thread messageThread([&message_client]() {
        while (message_client.isClientRunning()) {
            // 清空传感器数据
            M702_DEV sensor_data = {0}; // 临时存储解析后的传感器数据
            
            int ret = -1;
            int retryCount = 0;
            const int MAX_RETRY = 5;    // 最多重试5次
            const int RETRY_INTERVAL = 100; // 重试间隔100ms

            // ===== 新增：传感器读取失败时自动重试 =====
            while (retryCount < MAX_RETRY && message_client.isClientRunning()) {
                ret = m702_dev.read_m702_data(m702_dev.m702_fd, &sensor_data);
                
                // 读取成功，退出重试循环
                if (ret == 0) {
                    break;
                }

                // 只对-1/-2错误重试（-4/-5/-6是临时错误，无需重试）
                if (ret == -1 || ret == -2) {
                    retryCount++;
                    printf("传感器读取失败（错误码:%d），正在重试 [%d/%d]...\n", ret, retryCount, MAX_RETRY);
                    std::this_thread::sleep_for(std::chrono::milliseconds(RETRY_INTERVAL));
                } else {
                    // 临时错误（-4/-5/-6），直接退出重试
                    break;
                }
            }

            
            // 只有解析成功时才发送数据（ret==0）
            if (ret == 0) {
                // 拼接传感器数据字符串（保留原始格式）
                std::string message = "eco2: " + std::to_string(sensor_data.eco2) + 
                                      ", ech2o: " + std::to_string(sensor_data.ech2o) + 
                                      ", tvoc: " + std::to_string(sensor_data.tvoc) + 
                                      ", pm25: " + std::to_string(sensor_data.pm25) + 
                                      ", pm10: " + std::to_string(sensor_data.pm10) +
                                      ", temperature: " + std::to_string(sensor_data.temperature) +
                                      ", humidity: " + std::to_string(sensor_data.humidity);
                
                // 发送数据到服务器
                message_client.sendMessage(message);
                printf("已发送传感器数据: '%s'\n", message.c_str());
            } else {
                // 仅在严重错误时打印日志（避免刷屏）
                if (ret != -4 && ret != -5 && ret != -6) {
                    printf("读取M702数据失败，错误码: %d\n", ret);
                }
            }

            // 控制读取频率（2秒一次，匹配传感器数据更新频率）
            std::this_thread::sleep_for(std::chrono::seconds(2));
        }
    });

    // 6. 等待用户输入退出
    std::cout << "程序运行中，按任意键退出..." << std::endl;
    std::cin.get();

    // 7. 停止线程
    video_client.stop();
    message_client.stop();

    // 8. 等待线程结束
    if (videoThread.joinable()) {
        videoThread.join();
    }
    if (messageThread.joinable()) {
        messageThread.join();
    }

    // 9. 关闭串口（使用你定义的close_dev函数）
    m702_dev.close_dev(m702_dev.m702_fd);

    std::cout << "程序正常退出" << std::endl;
    return 0;
}