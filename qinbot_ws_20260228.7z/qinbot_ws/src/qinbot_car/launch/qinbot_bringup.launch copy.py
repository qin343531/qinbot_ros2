import os
from launch import LaunchDescription
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.actions import DeclareLaunchArgument
import yaml

def generate_launch_description():
    package_qinbot = 'qinbot_car'
    package_yadlidar = 'ydlidar_ros2_driver'

    # -------------------------- 核心修复：直接获取配置文件绝对路径（兼容 Foxy） --------------------------
    # 1. 找到 qinbot_car 功能包的安装路径
    qinbot_share_dir = FindPackageShare(package=package_qinbot).find(package_qinbot)
    # 2. 拼接 config 文件路径（确保 config 文件夹和 time_offset_config.yaml 存在）
    config_abs_path = os.path.join(qinbot_share_dir, "config", "time_offset_config.yaml")
    
    # 3. 读取 yaml 中的 time_offset 参数
    with open(config_abs_path, 'r') as f:
        config = yaml.safe_load(f)
    time_offset_default = config["time_offset"]

    # -------------------------- 声明参数（必须添加） --------------------------
    declare_time_offset_arg = DeclareLaunchArgument(
        "time_offset",
        default_value=str(time_offset_default),
        description="时间戳偏差值（单位：秒）"
    )

    ld = LaunchDescription()

    # 里程计节点（传递 time_offset）
    qinbot_bringup_node = Node(
        package=package_qinbot,
        executable='odom_pub',
        name='qinbot_odom_node',
        parameters=[
            {"time_offset": LaunchConfiguration("time_offset")}
        ],
        output='screen',
    )

    # 激光雷达节点（传递 time_offset）
    package_yadlidar_node = Node(
        package=package_yadlidar,
        executable='ydlidar_ros2_driver_node',
        name='ydlidar_ros2_driver_node',
        parameters=[
            {"time_offset": LaunchConfiguration("time_offset")}
        ],
        output='screen',
    )

    # 添加所有动作
    ld.add_action(declare_time_offset_arg)
    ld.add_action(qinbot_bringup_node)
    ld.add_action(package_yadlidar_node)

    return ld