import os
from launch import LaunchDescription
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument

def generate_launch_description():
    package_qinbot = 'qinbot_car'
    package_yadlidar = 'ydlidar_ros2_driver'
    package_im948 = 'im948'

    # 声明命令行参数（默认值设为 -1.5，可在启动时覆盖）
    declare_time_offset_arg = DeclareLaunchArgument(
        "time_offset",
        default_value="0.0",  # 默认时间偏差，按需调整
        description="时间戳偏差值（单位：秒）"
    )

    ld = LaunchDescription()

    # 里程计节点（接收命令行参数）
    qinbot_bringup_node = Node(
        package=package_qinbot,
        executable='odom_pub',
        name='qinbot_odom_node',
        parameters=[
            {"time_offset": LaunchConfiguration("time_offset")}
        ],
        output='screen',
    )

    # 激光雷达节点（接收相同的命令行参数）
    package_yadlidar_node = Node(
        package=package_yadlidar,
        executable='ydlidar_ros2_driver_node',
        name='ydlidar_ros2_driver_node',
        parameters=[
            {"time_offset": LaunchConfiguration("time_offset")}
        ],
        output='screen',
    )

    imu_node = Node(
        package=package_im948,
        executable='imu_pub',  # 根据你的 IMU 节点实际可执行文件名调整
        name='im948_imu_node',
        output='screen',
    )

    # 添加参数声明和节点
    ld.add_action(declare_time_offset_arg)
    ld.add_action(qinbot_bringup_node)
    ld.add_action(package_yadlidar_node)
    ld.add_action(imu_node)

    return ld

# ros2 launch qinbot_car qinbot_bringup.launch.py time_offset:=-1.7