#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "serial_comm.h"


// 创建串口通信对象
SerialComm serialComm;

//定义订阅者节点类
class KeyboardControl : public rclcpp::Node
{
public:
    KeyboardControl() : Node("keyboard_control")
    {
        //创建订阅者节点
        subscriber_ = this->create_subscription<geometry_msgs::msg::Twist>(
            "cmd_vel", 10, std::bind(&KeyboardControl::vel_callback, this, std::placeholders::_1)
        );
        RCLCPP_INFO(this->get_logger(), "Twist 订阅者已启动，等待消息...");
    }
    char serial_data[12];  
    int linear_speed;
    int angular_speed;
private:
    void vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg)
    {
        RCLCPP_INFO(this->get_logger(), "收到速度信息：");
        RCLCPP_INFO(this->get_logger(), "线速度: x=%.2f, 角速度: z=%.2f",
                    msg->linear.x, msg->angular.z);

        // -------------------------- 处理线速度（±99.99，完整保留两位小数） --------------------------
        float linear_x = msg->linear.x;
        char linear_sign = (linear_x >= 0) ? '+' : '-';  // 线速度符号
        int linear_raw = static_cast<int>(round(fabs(linear_x) * 100));  // 取绝对值放大100倍
        linear_raw %= 10000;  // 截断超出99.99的部分（保留0~9999）

        // -------------------------- 处理角速度（±99.99，完整保留两位小数） --------------------------
        float angular_z = msg->angular.z;
        char angular_sign = (angular_z >= 0) ? '+' : '-';  // 角速度符号
        int angular_raw = static_cast<int>(round(fabs(angular_z) * 100));  // 取绝对值放大100倍
        angular_raw %= 10000;  // 截断超出99.99的部分

        // -------------------------- 填充14字节数据包 --------------------------
        // 线速度部分（索引0~6）
        serial_data[0] = 's';                   // 起始标识
        serial_data[1] = 'l';                   // 线速度标识
        serial_data[2] = linear_sign;           // 线速度符号（'+'/'-'）
        serial_data[3] = static_cast<char>((linear_raw / 100) / 10 % 10 + '0');  // 整数十位
        serial_data[4] = static_cast<char>((linear_raw / 100) % 10 + '0');       // 整数个位
        serial_data[5] = static_cast<char>((linear_raw / 10) % 10 + '0');        // 小数第一位
        serial_data[6] = static_cast<char>(linear_raw % 10 + '0');               // 小数第二位

        // 角速度部分（索引7~12）
        serial_data[7] = 'a';                   // 角速度标识
        serial_data[8] = angular_sign;          // 角速度符号（'+'/'-'）
        serial_data[9] = static_cast<char>((angular_raw / 100) / 10 % 10 + '0'); // 整数十位
        serial_data[10] = static_cast<char>((angular_raw / 100) % 10 + '0');      // 整数个位
        serial_data[11] = static_cast<char>((angular_raw / 10) % 10 + '0');       // 小数第一位
        serial_data[12] = static_cast<char>(angular_raw % 10 + '0');              // 小数第二位

        serial_data[13] = 'e';                  // 结束标识（第14字节）

        send_strdata(&serialComm, serial_data, 14);  // 发送14字节数据
    }
    
    rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr subscriber_;
};


int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    serialComm.port = SERIAL_PORT;
    serialComm.baud_rate = BAUD_RATE;
    serialComm.timeout = TIMEOUT;

    // 打开串口
    if (open_serial(&serialComm) != 0) {
        return -1;  // 串口打开失败，退出程序
    }

    rclcpp::spin(std::make_shared<KeyboardControl>());
    rclcpp::shutdown();
    close_serial(&serialComm);  // 关闭串口
    return 0;
}
