#include "rclcpp/rclcpp.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2/LinearMath/Matrix3x3.h"
#include "serial_comm.h"
#include "geometry_msgs/msg/twist.hpp"
#include <cmath>
#include "rclcpp/qos.hpp"

#define ODOMDATA_NUM 9          // 数据包格式：s + LF_flag + L_pulse + RF_flag + R_pulse + Yaw_flag + Yaw_int + Yaw_dec + e（9字节）
#define PI 3.1415926
#define Wheel_Distance 0.21584  // 轮距（m）
#define ANGLE_TO_RAD (PI / 180.0f)  // 角度转弧度系数

// 精准参数定义
#define WHEEL_DIAMETER 0.065f    // 车轮直径（m）
#define PULSES_PER_ROTATION 1555 // 每圈脉冲数
#define UPDATE_PERIOD 0.01f      // 数据更新周期（10ms=0.01s）
#define PULSE_DISTANCE (PI * WHEEL_DIAMETER / PULSES_PER_ROTATION) // 脉冲当量（m/脉冲）
#define PULSE_SPEED (PULSE_DISTANCE / UPDATE_PERIOD) // ≈0.01313 m/(脉冲·s)

// 全局变量初始化（关键：避免野值）
SerialComm serial_odom;
unsigned char recv_c = 0;
unsigned char encoder_list[ODOMDATA_NUM] = {0};
unsigned char rev_flag = 0, rev_count = 0, success_flag = 0;
char LF_flag = '+', RF_flag = '+', Yaw_flag = '+'; // 符号位默认+

int encoder_L = 0, encoder_R = 0;  // 左右轮累计脉冲数
float speed_L = 0.0f, speed_R = 0.0f;  // 左右轮速度（m/s）
float linear_speed = 0.0f, angular_speed = 0.0f;  // 机体线速度、角速度

// Yaw角相关变量（角度制输入，弧度制存储）
float Yaw_angle = 0.0f;          // 当前Yaw角（rad）
float last_Yaw_angle = 0.0f;     // 上一帧Yaw角（用于计算角速度）

typedef struct{
    float x = 0.0f;  // 初始化位置为0，避免野值
    float y = 0.0f;
    float angle = 0.0f;                  // 机器人姿态角（rad）
    float linear_speed = 0.0f;
    float angular_speed = 0.0f;
}odom_t;

class QinbotOdom : public rclcpp::Node
{
public:
    QinbotOdom() : Node("qinbot_odom")
    {
        this->declare_parameter<double>("time_offset", 0.0);
        this->get_parameter("time_offset", time_offset_);
        // 订阅cmd_vel
        subscriber_ = this->create_subscription<geometry_msgs::msg::Twist>(
            "cmd_vel", 10, std::bind(&QinbotOdom::vel_callback, this, std::placeholders::_1)
        );
        RCLCPP_INFO(this->get_logger(), "Twist 订阅者已启动，等待消息...");

        // 发布odom（QoS配置正确）
        rclcpp::QoS qos_profile(10); // 队列深度=1，只存最新1帧
        qos_profile.reliable();  // 实时优先，丢包不重传
        qos_profile.durability_volatile();  // 不缓存历史消息
        publisher_ = this->create_publisher<nav_msgs::msg::Odometry>("odom", qos_profile);
        
        last_time_ = this->get_clock()->now();
        last_Yaw_angle = Yaw_angle; // 初始化上一帧Yaw角
        
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(66), 
            std::bind(&QinbotOdom::timer_callback, this)
        );

        // 核心：1ms定时器（和单片机上传频率对齐）
        timer_serial = this->create_wall_timer(
            std::chrono::microseconds(500), 
            std::bind(&QinbotOdom::timer_serialcallback, this)
        );
    }

private:
    void vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg);
    void timer_callback();
    void timer_serialcallback();
    void odom_process(unsigned char serial_list[]);
    void update_odom(double dt);
    void TransAngleInPI(float angle, float& out_angle);
    
    rclcpp::Time last_time_;
    char serial_data[14] = {0};  // 发送缓冲区初始化，避免野值
    odom_t odom;
    nav_msgs::msg::Odometry odom_msg;
    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr publisher_;
    rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr subscriber_;
    rclcpp::TimerBase::SharedPtr timer_, timer_serial;
    double time_offset_;  // 存储时间偏差值
};

// 更新里程计（核心逻辑不变）
void QinbotOdom::update_odom(double dt)
{
    double dt_s = dt;
    odom.angle = Yaw_angle;
    TransAngleInPI(odom.angle, odom.angle);

    // 计算角速度（限制范围避免异常）
    angular_speed = (odom.angle - last_Yaw_angle) / dt_s;
    if (angular_speed > 5.0f) {
        angular_speed = 5.0f;
    } else if (angular_speed < -5.0f) {
        angular_speed = -5.0f;
    }


    // 位置积分
    double delta_distance = odom.linear_speed * dt_s;
    odom.x += delta_distance * std::cos(odom.angle);
    odom.y += delta_distance * std::sin(odom.angle);

    last_Yaw_angle = odom.angle;
}

// 角度归一化（弧度制，-PI~PI）
void QinbotOdom::TransAngleInPI(float angle, float& out_angle)
{
    out_angle = angle;
    while (out_angle > PI) out_angle -= 2 * PI;
    while (out_angle < -PI) out_angle += 2 * PI;
}

// 发布odom（逻辑不变，优化四元数计算）
void QinbotOdom::timer_callback()
{
    //rclcpp::Time current_time = this->get_clock()->now();
    rclcpp::Time current_time = this->get_clock()->now();
      
    rclcpp::Duration offset_duration = rclcpp::Duration::from_seconds(time_offset_);
    odom_msg.header.stamp = current_time + offset_duration;
    double dt = (current_time  - last_time_).seconds();

    // 修正dt限制：适配50ms定时器（0.05s），只过滤极端异常值
    if (dt < 0.04) {  // 允许最小40ms（略低于50ms）
        dt = 0.04;
    } else if (dt > 0.06) { // 允许最大60ms（略高于50ms）
        dt = 0.06;
    }

    update_odom(dt);
    last_time_ = current_time;

    //odom_msg.header.stamp = current_time;
    odom_msg.header.frame_id = "odom";
    odom_msg.child_frame_id = "base_footprint";
    
    odom_msg.pose.pose.position.x = odom.x;
    odom_msg.pose.pose.position.y = odom.y;
    odom_msg.pose.pose.position.z = 0.0;

    // 用tf2计算四元数（更可靠，避免手动cos/sin错误）
    tf2::Quaternion q;
    q.setRPY(0, 0, odom.angle);
    odom_msg.pose.pose.orientation.x = q.x();
    odom_msg.pose.pose.orientation.y = q.y();
    odom_msg.pose.pose.orientation.z = q.z();
    odom_msg.pose.pose.orientation.w = q.w();

    // 速度信息
    odom_msg.twist.twist.linear.x = odom.linear_speed;
    odom_msg.twist.twist.angular.z = angular_speed;

    publisher_->publish(odom_msg);
}

// 串口读取（逻辑正确，仅解析成功后发布）
void QinbotOdom::timer_serialcallback()
{
    if(!read_char(&serial_odom, &recv_c))
    {
        if(recv_c == 's')
        {
            rev_flag = 1;
            rev_count = 0;
            encoder_list[rev_count] = 's';
        }
        else if(rev_flag == 1)
        {
            rev_count++;
            if(rev_count >= ODOMDATA_NUM)
            {
                rev_flag = 0;
                rev_count = 0;
                success_flag = 0;
            }
            else
            {
                encoder_list[rev_count] = recv_c;
                // 仅读到完整数据包（e结尾）时，解析+发布
                if(rev_count == (ODOMDATA_NUM - 1) && encoder_list[ODOMDATA_NUM - 1] == 'e')
                {
                    success_flag = 1;
                    odom_process(encoder_list);
                    rev_flag = 0;
                    rev_count = 0;
                }
            }
        }
    }
}

// 数据解析（逻辑正确）
void QinbotOdom::odom_process(unsigned char serial_list[])
{
    // 1. 左右轮脉冲解析
    LF_flag = serial_list[1];
    int L_pulse = static_cast<int>(serial_list[2]);
    if(LF_flag == '+')
    {
        encoder_L += L_pulse;
        speed_L = L_pulse * PULSE_SPEED;
    }
    else
    {   
        encoder_L -= L_pulse;
        speed_L = -L_pulse * PULSE_SPEED;
    }

    RF_flag = serial_list[3];
    int R_pulse = static_cast<int>(serial_list[4]);
    if(RF_flag == '+')
    {
        encoder_R += R_pulse;
        speed_R = R_pulse * PULSE_SPEED;
    }
    else
    {
        encoder_R -= R_pulse;
        speed_R = -R_pulse * PULSE_SPEED;
    }

    // 2. Yaw角解析（角度制→弧度制）
    Yaw_flag = serial_list[5];
    int Yaw_int = static_cast<int>(serial_list[6]);
    int Yaw_dec = static_cast<int>(serial_list[7]);
    float yaw_angle_deg = Yaw_int + (Yaw_dec / 100.0f);
    //float yaw_angle_deg = Yaw_int;
    if(Yaw_flag == '-') yaw_angle_deg = -yaw_angle_deg;
    Yaw_angle = yaw_angle_deg * ANGLE_TO_RAD;

    // 3. 运动学正解
    linear_speed = (speed_L + speed_R) / 2.0f;
    odom.linear_speed = linear_speed;

    // 调试打印（可选，确认解析正确）
    //RCLCPP_INFO(this->get_logger(), "解析成功：线速度=%.3f m/s, Yaw=%.2f°", linear_speed, yaw_angle_deg);
}

// 发送cmd_vel（逻辑正确）
void QinbotOdom::vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg)
{
    // RCLCPP_INFO(this->get_logger(), "收到速度信息：线速度x=%.2f, 角速度z=%.2f",
    //             msg->linear.x, msg->angular.z);

    float linear_x = msg->linear.x;
    char linear_sign = (linear_x >= 0) ? '+' : '-';
    int linear_raw = static_cast<int>(round(fabs(linear_x) * 100));
    linear_raw %= 10000;

    float angular_z = msg->angular.z;
    char angular_sign = (angular_z >= 0) ? '+' : '-';
    int angular_raw = static_cast<int>(round(fabs(angular_z) * 100));
    angular_raw %= 10000;

    // 填充14字节数据包
    serial_data[0] = 's';
    serial_data[1] = 'l';
    serial_data[2] = linear_sign;
    serial_data[3] = static_cast<char>((linear_raw / 100) / 10 % 10 + '0');
    serial_data[4] = static_cast<char>((linear_raw / 100) % 10 + '0');
    serial_data[5] = static_cast<char>((linear_raw / 10) % 10 + '0');
    serial_data[6] = static_cast<char>(linear_raw % 10 + '0');
    serial_data[7] = 'a';
    serial_data[8] = angular_sign;
    serial_data[9] = static_cast<char>((angular_raw / 100) / 10 % 10 + '0');
    serial_data[10] = static_cast<char>((angular_raw / 100) % 10 + '0');
    serial_data[11] = static_cast<char>((angular_raw / 10) % 10 + '0');
    serial_data[12] = static_cast<char>(angular_raw % 10 + '0');
    serial_data[13] = 'e';

    send_strdata(&serial_odom, serial_data, 14);
}

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    // 串口初始化（确保SERIAL_PORT/BAUD_RATE/TIMEOUT已定义）
    serial_odom.port = SERIAL_PORT;
    serial_odom.baud_rate = BAUD_RATE;
    serial_odom.timeout = TIMEOUT;
    if (open_serial(&serial_odom) != 0) {
        std::cerr << "串口初始化失败" << std::endl;
        return -1;
    }
    RCLCPP_INFO(rclcpp::get_logger("main"), "里程计节点启动成功！");
    rclcpp::spin(std::make_shared<QinbotOdom>());
    rclcpp::shutdown();
    close_serial(&serial_odom);
    return 0;
}
