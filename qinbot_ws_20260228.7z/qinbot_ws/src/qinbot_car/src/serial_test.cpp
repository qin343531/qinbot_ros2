#include "serial_comm.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>

int main()
{
    // 创建并初始化串口通信对象（关键修改：分配内存）
    SerialComm serial;  // 直接使用栈变量
    serial.port = SERIAL_PORT;
    serial.baud_rate = BAUD_RATE;
    serial.timeout = TIMEOUT;
    serial.fd = -1;  // 初始化为无效值

    // 打开串口
    serial.fd = open(serial.port, O_RDWR | O_NOCTTY);
    if (serial.fd == -1) {
        perror("无法打开串口");
        return -1;
    }

    // 配置串口
    struct termios options;
    if(tcgetattr(serial.fd, &options) != 0) {
        perror("获取串口属性失败");
        close(serial.fd);
        return -1;
    }

    // 设置波特率
    cfsetispeed(&options, serial.baud_rate);
    cfsetospeed(&options, serial.baud_rate);

    // 8N1配置
    options.c_cflag &= ~PARENB; // 无校验
    options.c_cflag &= ~CSTOPB; // 1停止位
    options.c_cflag &= ~CSIZE;  // 清除数据位掩码
    options.c_cflag |= CS8;     // 8数据位
    options.c_cflag |= (CLOCAL | CREAD);  // 关键本地控制

    // 输入输出模式配置
    options.c_iflag &= ~(IXON | IXOFF | IXANY | INLCR | ICRNL);
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    options.c_oflag &= ~OPOST;

    // 超时设置（单位：0.1秒）
    options.c_cc[VMIN] = 0;
    options.c_cc[VTIME] = 5;  // 0.5秒超时

    if(tcsetattr(serial.fd, TCSANOW, &options) != 0) {
        perror("设置串口属性失败");
        close(serial.fd);
        return -1;
    }

    printf("串口 %s 已打开，波特率：%d\n", serial.port, get_baud_rate(BAUD_RATE));
    usleep(2000000);  // 100ms延迟

    // 主循环（添加延迟和错误处理）
    while(1) 
    {
        printf("准备发送: 字符串=%s", "a");
        if(send_strdata(&serial, "a",1) < 0) 
        {
            fprintf(stderr, "发送数据失败\n");
            break;
        }
        send_strdata(&serial, "\r",1);
        send_strdata(&serial, "\n",1);
        usleep(100000);  // 100ms延迟
    }

    close(serial.fd);
    return 0;
}
