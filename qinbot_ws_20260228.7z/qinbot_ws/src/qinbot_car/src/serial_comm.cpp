#include "serial_comm.h"


// 映射宏值（保持不变）
int get_baud_rate(speed_t baud_rate)
{
    switch (baud_rate) {
        case B9600: return 9600;
        case B19200: return 19200;
        case B38400: return 38400;
        case B57600: return 57600;
        case B115200: return 115200;
        case B230400: return 230400;
        default: return -1; // 未知波特率
    }
}


// 修正后的串口初始化函数（适配你的结构体，解决接收问题）
int open_serial(SerialComm *serial) 
{
    // 1. 参数校验（避免空指针）
    if (serial == nullptr || serial->port == nullptr) {
        std::cerr << "错误：SerialComm 或串口路径为空" << std::endl;
        return -1;
    }
    if (serial->timeout < 0) {
        std::cerr << "错误：超时时间不能为负数" << std::endl;
        return -1;
    }

    // 2. 打开串口：O_NONBLOCK + 后续超时配置，兼顾灵活性和稳定性
    serial->fd = open(serial->port, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (serial->fd == -1) {
        perror("无法打开串口");
        return -1;
    }

    struct termios options;
    if (tcgetattr(serial->fd, &options) != 0) {
        perror("获取串口属性失败");
        close(serial->fd);
        serial->fd = -1;
        return -1;
    }

    // 3. 设置波特率（使用结构体中的 baud_rate，而非硬编码）
    if (cfsetispeed(&options, serial->baud_rate) == -1 || 
        cfsetospeed(&options, serial->baud_rate) == -1) {
        perror("设置波特率失败");
        close(serial->fd);
        serial->fd = -1;
        return -1;
    }



    // 4. 数据格式：8N1（8位数据位+无校验+1位停止位）
    options.c_cflag &= ~PARENB;    // 无校验
    options.c_cflag &= ~CSTOPB;    // 1位停止位
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;        // 8位数据位

    // 5. 控制模式：启用接收，忽略调制解调器控制线（本地模式，避免被其他设备干扰）
    options.c_cflag |= (CLOCAL | CREAD);

    // 6. 输入模式：禁用流控+禁用特殊字符处理（避免数据被篡改）
    options.c_iflag &= ~(IXON | IXOFF | IXANY);  // 禁用软件流控
    options.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL);  // 不处理回车/换行等特殊字符，这是泰山派与单片机通信的重要配置

    // 7. 本地模式：禁用规范模式（不缓冲行数据），禁用回显/信号（避免干扰接收）
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);

    // 8. 输出模式：原样发送数据（不做任何转换）
    options.c_oflag &= ~OPOST;
    options.c_oflag &= ~(ONLCR | OCRNL);

    // 9. 读超时配置（核心改进！使用结构体中的 timeout 字段）
    int vtime = serial->timeout / 100;  // VTIME 单位：0.1秒，转换为结构体中的毫秒超时
    options.c_cc[VTIME] = (vtime > 255) ? 255 : vtime;  // VTIME 最大值255（25.5秒）
    options.c_cc[VMIN] = 0;  // 最小读取字节数：0（有数据就返回，无数据超时后返回）

    // 10. 应用配置并清空缓冲区（避免读取历史残留数据）
    if (tcsetattr(serial->fd, TCSANOW, &options) != 0) {
        perror("设置串口属性失败");
        close(serial->fd);
        serial->fd = -1;
        return -1;
    }
    tcflush(serial->fd, TCIOFLUSH);  // 清空输入输出缓冲区

    printf("串口 %s 已打开，波特率：%d，超时：%dms\n", 
           serial->port, 
           get_baud_rate(serial->baud_rate),
           serial->timeout);
    return 0;
}

// 单字符接收函数（适配你的结构体，支持超时）
int read_char(SerialComm *serial, unsigned char *recv_char) 
{
    // 1. 参数校验
    if (serial == nullptr || recv_char == nullptr) {
        std::cerr << "错误：SerialComm 指针或接收缓冲区为空" << std::endl;
        return -3;
    }
    if (serial->fd == -1) {
        std::cerr << "错误：串口未打开" << std::endl;
        return -1;
    }

    // 2. 动态切换阻塞/非阻塞模式（根据结构体中的超时配置）
    int flags = fcntl(serial->fd, F_GETFL, 0);
    if (flags == -1) {
        perror("获取文件状态失败");
        return -3;
    }
    if (serial->timeout > 0) {
        // 超时模式：清除非阻塞标志，按 VTIME 等待数据
        fcntl(serial->fd, F_SETFL, flags & ~O_NONBLOCK);
    } else {
        // 非阻塞模式：立即返回，不管有没有数据
        fcntl(serial->fd, F_SETFL, flags | O_NONBLOCK);
    }

    // 3. 读取单个字符
    ssize_t read_len = read(serial->fd, recv_char, 1);
    if (read_len == 1) {
        // 成功接收：返回0，recv_char 存储接收到的字符
        return 0;
    } else if (read_len == 0) {
        // 超时无数据（仅在超时模式下触发）
        return -2;
    } else {
        // 读取失败：区分“无数据”和“真错误”
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            // 非阻塞模式下无数据，或超时模式下超时
            return -2;
        } else {
            perror("读取字符失败");
            return -3;
        }
    }
}

// 保留你原有的发送/关闭函数（无需修改）
int send_data(SerialComm *serial, char data) 
{
    if (serial->fd == -1) 
    {
        std::cout << "串口未打开" << std::endl;
        return -1;
    }
    if (write(serial->fd, &data, 1) != 1) 
    {
        perror("写入串口失败");
        return -1;
    }
    return 0;
}

int send_strdata(SerialComm *serial, const char* data, int data_len)
{
    if (serial->fd == -1) 
    {
        std::cout << "串口未打开" << std::endl;
        return -1;
    }

    const size_t len = data_len;
    ssize_t written = write(serial->fd, data, len);
    
    if (written != (ssize_t)len) 
    {
        perror("写入串口失败");
        return -1;
    }

    return 0;
}

void close_serial(SerialComm *serial) 
{
    if (serial != nullptr && serial->fd != -1) {
        close(serial->fd);
        serial->fd = -1;  // 重置文件描述符，避免重复关闭
        printf("串口 %s 已关闭\n", serial->port);
    }
}

// 使用示例（测试初始化+接收）
// int main() {
//     // 初始化串口参数（根据实际硬件修改）
//     SerialComm serial = {
//         .port = "/dev/ttyUSB0",  // 串口路径（如 "/dev/ttyS0" 或 "/dev/ttyAMA0"）
//         .baud_rate = B115200,    // 波特率需与外设一致
//         .timeout = 1000,         // 读超时1秒（1000ms）
//         .fd = -1                 // 初始化为无效描述符
//     };

//     // 打开串口
//     if (open_serial(&serial) != 0) {
//         std::cerr << "串口初始化失败" << std::endl;
//         return -1;
//     }

//     // 循环接收字符（测试接收功能）
//     unsigned char recv_c;
//     printf("等待接收数据（超时1秒）...\n");
//     while (1) {
//         int ret = read_char(&serial, &recv_c);
//         if (ret == 0) {
//             // 成功接收：打印字符（区分可打印字符和十六进制）
//             if (isprint(recv_c)) {
//                 printf("收到可打印字符：'%c'（ASCII：%d）\n", recv_c, recv_c);
//             } else {
//                 printf("收到非可打印字符：0x%02X\n", recv_c);
//             }
//             break;  // 接收一次后退出，可删除break实现循环接收
//         } else if (ret == -2) {
//             printf("超时未收到数据\n");
//             break;
//         } else {
//             printf("接收错误（错误码：%d）\n", ret);
//             break;
//         }
//     }

//     // 关闭串口
//     close_serial(&serial);
//     return 0;
// }



/**

#include "serial_comm.h"

//映射宏值
int get_baud_rate(speed_t baud_rate)
{
    switch (baud_rate) {
        case B9600: return 9600;
        case B19200: return 19200;
        case B38400: return 38400;
        case B57600: return 57600;
        case B115200: return 115200;
        case B230400: return 230400;
        default: return -1; // 未知波特率
    }
}


// 打开串口
int open_serial(SerialComm *serial) 
{
    serial->fd = open(serial->port, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (serial->fd == -1) {
        perror("无法打开串口");
        return -1;
    }

    struct termios options;
    tcgetattr(serial->fd, &options);

    // 设置波特率
    if (cfsetispeed(&options, BAUD_RATE) == -1) {
        perror("设置输入波特率失败");
        close(serial->fd);
        return -1;
    }
    if (cfsetospeed(&options, BAUD_RATE) == -1) {
        perror("设置输出波特率失败");
        close(serial->fd);
        return -1;
    }

    // 设置其他串口选项（数据位、停止位等）
    options.c_cflag &= ~PARENB;  // 无校验位
    options.c_cflag &= ~CSTOPB;  // 1位停止位
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;      // 8位数据位

    options.c_cflag |= (CLOCAL | CREAD);  // 允许接受数据
    options.c_iflag &= ~(IXON | IXOFF | IXANY);  // 禁用流控制
    options.c_iflag &= ~ICANON;  // 禁用规范模式
    options.c_iflag &= ~ECHO;    // 禁用回显
    options.c_iflag &= ~ECHOE;   // 禁用回显（输入时不显示字符）
    options.c_iflag &= ~ISIG;    // 禁用信号

    tcsetattr(serial->fd, TCSANOW, &options);  // 应用设置

    printf("串口 %s 已打开，波特率：%d\n", serial->port, get_baud_rate(BAUD_RATE));
    return 0;
}

// 向串口发送数据，修改为发送单个字符
int send_data(SerialComm *serial, char data) 
{
    if (serial->fd == -1) 
    {
        std::cout << "串口未打开" << std::endl;
        return -1;
    }
    if (write(serial->fd, &data, 1) != 1) 
    {
        perror("写入串口失败");
        return -1;
    }
    return 0;
}

int send_strdata(SerialComm *serial, const char* data, int data_len)
{
    if (serial->fd == -1) 
    {
        std::cout << "串口未打开" << std::endl;
        return -1;
    }

    //size_t len = strlen(data);  // 计算字符串长度
    const size_t len = data_len;
    ssize_t written = write(serial->fd, data, len);
    
    if (written != (ssize_t)len) 
    {
        perror("写入串口失败");
        return -1;
    }

    return 0;
}



// 关闭串口
void close_serial(SerialComm *serial) 
{
    if (serial->fd != -1) {
        close(serial->fd);
        printf("串口 %s 已关闭\n", serial->port);
    }
}

int read_char(SerialComm *serial, unsigned char *recv_char) 
{
    // 1. 参数校验
    if (serial == nullptr || recv_char == nullptr) {
        std::cerr << "错误：SerialComm 指针或接收缓冲区为空" << std::endl;
        return -3;
    }
    if (serial->fd == -1) {
        std::cerr << "错误：串口未打开" << std::endl;
        return -1;
    }

    // 2. 非阻塞读取（最多读1个字符）
    ssize_t read_len = read(serial->fd, recv_char, 1);
    if (read_len == 1) {
        // 3. 读取成功
        return 0;
    } else if (read_len == 0) {
        // 4. 无数据可读（非阻塞模式下正常）
        return -2;
    } else {
        // 5. 读取失败：区分“无数据”和“真错误”
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            // 串口暂时无数据，非错误
            return -2;
        } else {
            perror("读取单个字符失败");
            return -3;
        }
    }
}


*/