def main():
    print('Hi from im948.')


if __name__ == '__main__':
    main()
