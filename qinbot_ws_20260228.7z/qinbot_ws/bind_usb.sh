#!/bin/bash
# 脚本功能：将指定的当前串口端口，绑定到固定名称的软链接（按设备名称区分）
# 用法：./bind_serial_port.sh [当前端口] [设备名称]
# 示例：
# 绑定激光雷达：./bind_serial_port.sh /dev/ttyUSB1 ydlidar
# 绑定里程计：./bind_serial_port.sh /dev/ttyUSB0 odom
# 绑定IMU：./bind_serial_port.sh /dev/ttyUSB2 imu

# 检查参数数量（必须输入2个参数：当前端口 + 设备名称）
if [ $# -ne 2 ]; then
    echo "❌ 用法错误！正确用法："
    echo "  ./bind_serial_port.sh [当前端口] [设备名称]"
    echo "  示例："
    echo "    绑定激光雷达：./bind_serial_port.sh /dev/ttyUSB1 ydlidar"
    echo "    绑定里程计：./bind_serial_port.sh /dev/ttyUSB0 odom"
    echo "    绑定IMU：./bind_serial_port.sh /dev/ttyUSB2 imu"
    exit 1
fi

# 接收参数
CURRENT_PORT=$1  # 第一个参数：当前端口（比如 /dev/ttyUSB1）
DEVICE_NAME=$2   # 第二个参数：设备名称（ydlidar/odom/imu）

# 定义每个设备对应的固定绑定端口（可自定义）
case $DEVICE_NAME in
    ydlidar)
        TARGET_LINK="/dev/ydlidar"  # 激光雷达固定端口
        ;;
    odom)
        TARGET_LINK="/dev/odom_serial"  # 里程计固定端口
        ;;
    imu)
        TARGET_LINK="/dev/imu_serial"  # IMU固定端口
        ;;
    *)
        echo "❌ 设备名称错误！仅支持：ydlidar/odom/imu"
        exit 1
        ;;
esac

# 检查当前端口是否存在
if [ ! -e "$CURRENT_PORT" ]; then
    echo "❌ 当前端口 $CURRENT_PORT 不存在！请检查设备是否插入或端口是否正确。"
    exit 1
fi

# 开始绑定（覆盖已存在的链接）
echo "🔧 开始绑定设备..."
echo "当前端口：$CURRENT_PORT"
echo "设备名称：$DEVICE_NAME"
echo "绑定端口：$TARGET_LINK"

# 1. 删除旧的软链接（如果存在）
if [ -L "$TARGET_LINK" ]; then
    sudo rm -f "$TARGET_LINK"
    echo "✅ 已删除旧绑定：$TARGET_LINK"
fi

# 2. 创建新的软链接（绑定当前端口到固定名称）
sudo ln -s "$CURRENT_PORT" "$TARGET_LINK"
echo "✅ 已创建新绑定：$CURRENT_PORT -> $TARGET_LINK"

# 3. 赋予读写权限（避免权限不足）
sudo chmod 666 "$CURRENT_PORT"
sudo chmod 666 "$TARGET_LINK"
echo "✅ 已赋予端口读写权限"

# 4. 验证绑定结果
if [ -L "$TARGET_LINK" ] && [ "$(readlink "$TARGET_LINK")" == "$CURRENT_PORT" ]; then
    echo -e "\n🎉 设备绑定成功！"
    echo "以后不管设备插哪个USB口，只要重新运行此脚本绑定，代码/Launch文件中直接使用：$TARGET_LINK"
else
    echo -e "\n❌ 设备绑定失败！请检查权限或端口是否被占用。"
    exit 1
fi
