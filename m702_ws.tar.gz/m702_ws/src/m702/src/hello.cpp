#include <stdio.h>
#include <iostream>


int main()
{
    std::cout << "Hello M702!" << std::endl;
    return 0;
}