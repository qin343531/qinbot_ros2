#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <stdint.h>
#include <errno.h>

#define FRAME_SIZE 17
#define FRAME_HEADER1 0x3C
#define FRAME_HEADER2 0x02

#define BAUDRATE B9600
#define SERIAL_DEVICE "/dev/ttyS0"

typedef struct {
    uint16_t eco2;      // CO₂浓度 (ppm)
    uint16_t ech2o;     // 甲醛浓度 (ppb)
    uint16_t tvoc;      // TVOC浓度 (ppb)
    uint16_t pm25;      // PM2.5浓度 (μg/m³)
    uint16_t pm10;      // PM10浓度 (μg/m³)
    float temperature;  // 温度 (℃)
    float humidity;     // 湿度 (%RH)
} m702_data_t;

int open_serial(const char *dev, int baudrate) {
    int fd = open(dev, O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1) {
        perror("open failed");
        return -1;
    }

    struct termios tty;
    if (tcgetattr(fd, &tty) != 0) {
        perror("tcgetattr failed");
        close(fd);
        return -1;
    }

    cfsetospeed(&tty, baudrate);
    cfsetispeed(&tty, baudrate);

    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
    tty.c_cflag &= ~(PARENB | PARODD);
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CRTSCTS;
    tty.c_cflag |= (CLOCAL | CREAD);

    tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    tty.c_oflag &= ~OPOST;

    tty.c_cc[VMIN]  = 0;
    tty.c_cc[VTIME] = 10;

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        perror("tcsetattr failed");
        close(fd);
        return -1;
    }

    return fd;
}

int parse_m702_frame(uint8_t *buf, m702_data_t *data) {
    if (buf[0] != FRAME_HEADER1 || buf[1] != FRAME_HEADER2) {
        return -1;
    }

    uint8_t checksum = 0;
    for (int i = 0; i < 16; i++) {
        checksum += buf[i];
    }
    if ((checksum & 0xFF) != buf[16]) {
        return -2;
    }

    data->eco2 = (buf[2] << 8) | buf[3];
    data->ech2o = (buf[4] << 8) | buf[5];
    data->tvoc = (buf[6] << 8) | buf[7];
    data->pm25 = (buf[8] << 8) | buf[9];
    data->pm10 = (buf[10] << 8) | buf[11];

    uint8_t temp_int = buf[12];
    uint8_t temp_dec = buf[13];
    if (temp_int & 0x80) {
        data->temperature = -((temp_int & 0x7F) + temp_dec / 100.0f);
    } else {
        data->temperature = (temp_int + temp_dec / 100.0f);
    }

    uint8_t hum_int = buf[14];
    uint8_t hum_dec = buf[15];
    data->humidity = hum_int + hum_dec / 100.0f;

    return 0;
}

int main() {
    const char *serial_dev = SERIAL_DEVICE;
    int fd = open_serial(serial_dev, BAUDRATE);
    if (fd < 0) {
        return 1;
    }

    uint8_t buf[FRAME_SIZE];
    m702_data_t data;

    while (1) {
        ssize_t n = read(fd, buf, FRAME_SIZE);
        if (n < 0) {
            if (errno != EAGAIN) {
                perror("read failed");
                break;
            }
            usleep(1000);
            continue;
        } else if (n != FRAME_SIZE) {
            usleep(1000);
            continue;
        }

        int ret = parse_m702_frame(buf, &data);
        if (ret == 0) {
            printf("CO₂: %u ppm\n", data.eco2);
            printf("甲醛: %u ppb\n", data.ech2o);
            printf("TVOC: %u ppb\n", data.tvoc);
            printf("PM2.5: %u μg/m³\n", data.pm25);
            printf("PM10: %u μg/m³\n", data.pm10);
            printf("温度: %.2f ℃\n", data.temperature);
            printf("湿度: %.2f %%RH\n", data.humidity);
            printf("------------------------\n");
        } else if (ret == -1) {
            // 帧头不匹配，丢弃数据
        } else if (ret == -2) {
            fprintf(stderr, "校验和错误\n");
        }   

        //100ms读取一次数据
        usleep(10000);
    }

    close(fd);
    return 0;
}