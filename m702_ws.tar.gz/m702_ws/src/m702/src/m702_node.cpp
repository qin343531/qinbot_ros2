#include <stdio.h>
#include <stdlib.h>
#include "m702_dev.h"
#include <iostream>
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

using namespace std::chrono_literals;

uint8_t buf[FRAME_SIZE];
M702_DEV m702_dev;

class M702Node : public rclcpp::Node
{
public:
    M702Node();
    ~M702Node();
private:
    void timer_callback();


    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
};
    
M702Node::M702Node() : Node("m702_node")
{
    // 创建发布者
    publisher_ = this->create_publisher<std_msgs::msg::String>("m702_topic", 10); 
    // 创建定时器，每秒发布一次消息
    timer_ = this->create_wall_timer(
        2s,
        std::bind(&M702Node::timer_callback, this)
    );

    m702_dev.m702_fd = m702_dev.open_dev(SERIAL_DEVICE, BAUDRATE);
    if (m702_dev.m702_fd < 0) {
        RCLCPP_ERROR(this->get_logger(), "无法打开串口设备！");
        return;
    }
    RCLCPP_INFO(this->get_logger(), "M702发布节点已启动！");
}

M702Node::~M702Node()
{
    if (m702_dev.m702_fd >= 0) {
        m702_dev.close_dev(m702_dev.m702_fd);
    }
}

void M702Node::timer_callback()
{
    std_msgs::msg::String message;
    // 先清空数据，避免复用旧值
    m702_dev.eco2 = 0;
    m702_dev.ech2o = 0;
    m702_dev.tvoc = 0;
    m702_dev.pm25 = 0;
    m702_dev.pm10 = 0;
    m702_dev.temperature = 0.0f;
    m702_dev.humidity = 0.0f;
    int ret = m702_dev.read_m702_data(m702_dev.m702_fd, &m702_dev);
    if (ret == 0) {
        message.data = "eco2: " + std::to_string(m702_dev.eco2) + 
                       ", ech2o: " + std::to_string(m702_dev.ech2o) + 
                       ", tvoc: " + std::to_string(m702_dev.tvoc) + 
                       ", pm25: " + std::to_string(m702_dev.pm25) + 
                       ", pm10: " + std::to_string(m702_dev.pm10) +
                       ", temperature: " + std::to_string(m702_dev.temperature) +
                       ", humidity: " + std::to_string(m702_dev.humidity);
        publisher_->publish(message);
        RCLCPP_INFO(this->get_logger(), "已发布消息: '%s'", message.data.c_str());
    }
    else {
        RCLCPP_WARN(this->get_logger(), "读取M702数据失败，错误码: %d", ret);
    }
}

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<M702Node>());
    rclcpp::shutdown();
    return 0;
}