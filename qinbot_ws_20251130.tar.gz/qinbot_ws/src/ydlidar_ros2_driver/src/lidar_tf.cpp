#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "tf2_ros/static_transform_broadcaster.h"
#include "geometry_msgs/msg/transform_stamped.hpp"

class StaticTfPublisher : public rclcpp::Node
{
public:
    StaticTfPublisher()
        : Node("static_tf_publisher")
    {
        tf_broadcaster_ = std::make_shared<tf2_ros::StaticTransformBroadcaster>(this);

        geometry_msgs::msg::TransformStamped static_transform;
        static_transform.header.stamp = this->get_clock()->now();
        static_transform.header.frame_id = "base_link";  // 父坐标系
        static_transform.child_frame_id = "laser_frame";       // 子坐标系

        // 位置偏移（单位：米）
        static_transform.transform.translation.x = 0.0;
        static_transform.transform.translation.y = 0.0;
        static_transform.transform.translation.z = 0.1;

        // 姿态偏移（四元数表示，无旋转为 0 0 0 1）
        static_transform.transform.rotation.x = 0.0;
        static_transform.transform.rotation.y = 0.0;
        static_transform.transform.rotation.z = 0.0;
        static_transform.transform.rotation.w = 1.0;

        tf_broadcaster_->sendTransform(static_transform);
        RCLCPP_INFO(this->get_logger(), "Static TF from base_link to laser published.");
    }

private:
    std::shared_ptr<tf2_ros::StaticTransformBroadcaster> tf_broadcaster_;
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<StaticTfPublisher>());
    rclcpp::shutdown();
    return 0;
}

