import os
from launch import LaunchDescription
from launch.substitutions import LaunchConfiguration,PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    package_qinbot = 'qinbot_car'
    package_yadlidar = 'ydlidar_ros2_driver'

    ld = LaunchDescription()
    ydlidar_share_dir = FindPackageShare(package=package_yadlidar).find(package_yadlidar)
    # ydlidar_params_path = PathJoinSubstitution(
    #     [ydlidar_share_dir, 'params', 'ydlidar.yaml']  # 默认配置文件路径
    # )

    qinbot_bringup_node = Node(
        package = package_qinbot,
        executable = 'odom_pub',
        name='qinbot_odom_node',
        output='screen',
    )

    package_yadlidar_node = Node(
        package = package_yadlidar,
        executable = 'ydlidar_ros2_driver_node',
        name='ydlidar_ros2_driver_node',
        output='screen',
        # parameters=[
        #     LaunchConfiguration('ydlidar_params', default=ydlidar_params_path)
        # ],
    )

    ld.add_action(qinbot_bringup_node)
    ld.add_action(package_yadlidar_node)

    return ld