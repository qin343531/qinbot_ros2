#include "rclcpp/rclcpp.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2/LinearMath/Matrix3x3.h"
#include "serial_comm.h"
#include "geometry_msgs/msg/twist.hpp"
#include <cmath>
#include "rclcpp/qos.hpp"

#define ODOMDATA_NUM 9          // 数据包格式：s + LF_flag + L_pulse + RF_flag + R_pulse + Yaw_flag + Yaw_int + Yaw_dec + e（9字节）
#define PI 3.1415926
#define Wheel_Distance 0.21584  // 轮距（m）
#define ANGLE_TO_RAD (PI / 180.0f)  // 角度转弧度系数（关键新增）

// 精准参数定义
#define WHEEL_DIAMETER 0.065f    // 车轮直径（m）
#define PULSES_PER_ROTATION 1555 // 每圈脉冲数
#define UPDATE_PERIOD 0.01f      // 数据更新周期（10ms=0.01s）
#define PULSE_DISTANCE (M_PI * WHEEL_DIAMETER / PULSES_PER_ROTATION) // 脉冲当量（m/脉冲）
#define PULSE_SPEED (PULSE_DISTANCE / UPDATE_PERIOD) // ≈0.01313 m/(脉冲·s)

SerialComm serial_odom;
unsigned char recv_c;
unsigned char encoder_list[ODOMDATA_NUM];
unsigned char rev_flag=0, rev_count=0, success_flag;
char LF_flag, RF_flag, Yaw_flag; // 符号位（'+'/'-'）用char更合理

int encoder_L = 0, encoder_R = 0;  // 左右轮累计脉冲数
float speed_L = 0.0f, speed_R = 0.0f;  // 左右轮速度（m/s）
float linear_speed = 0.0f, angular_speed = 0.0f;  // 机体线速度、角速度

// Yaw角相关变量（角度制输入，弧度制存储）
float Yaw_angle = 0.0f;          // 当前Yaw角（rad，内部统一用弧度制）
float last_Yaw_angle = 0.0f;     // 上一帧Yaw角（用于计算角速度）

typedef struct{
    float x;
    float y;
    float angle;                  // 机器人姿态角（rad，用Yaw_angle赋值）
    float linear_speed;
    float angular_speed;
}odom_t;

class QinbotOdom : public rclcpp::Node
{
public:
    QinbotOdom() : Node("qinbot_odom")
    {
        // 订阅cmd_vel
        subscriber_ = this->create_subscription<geometry_msgs::msg::Twist>(
            "cmd_vel", 10, std::bind(&QinbotOdom::vel_callback, this, std::placeholders::_1)
        );
        RCLCPP_INFO(this->get_logger(), "Twist 订阅者已启动，等待消息...");

        // 发布odom
        //publisher_ = this->create_publisher<nav_msgs::msg::Odometry>("odom", 10);
        rclcpp::QoS qos_profile(1); // 队列深度=1，只存最新1帧
        qos_profile.best_effort();  // 对应原来的BEST_EFFORT
        qos_profile.durability_volatile();  // 对应原来的VOLATILE
        // 初始化发布器（类型完全匹配，无编译错误）
        publisher_ = this->create_publisher<nav_msgs::msg::Odometry>("odom", qos_profile);
        // rclcpp::Time hardware_time = this->get_clock()->now();
        // rclcpp::Time calibrated_time = hardware_time - rclcpp::Duration::from_seconds(49.0);
        // last_time_ = calibrated_time;
        
        last_time_ = this->get_clock()->now();
        last_Yaw_angle = Yaw_angle; // 初始化上一帧Yaw角
        
        // 定时器：100ms发布一次odom
        // timer_ = this->create_wall_timer(
        //     std::chrono::milliseconds(10), 
        //     std::bind(&QinbotOdom::timer_callback, this)
        // );

        // 定时器：1ms读取串口数据
        timer_serial = this->create_wall_timer(
            std::chrono::milliseconds(10), 
            std::bind(&QinbotOdom::timer_serialcallback, this)
        );
    }

private:
    void vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg);
    void timer_callback();
    void timer_serialcallback();
    void odom_process(unsigned char serial_list[]);
    void update_odom(double dt);
    void TransAngleInPI(float angle, float& out_angle);
    
    rclcpp::Time last_time_;
    char serial_data[14];  // 发送缓冲区（14字节，适配之前的14字节格式）
    odom_t odom;
    nav_msgs::msg::Odometry odom_msg;
    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr publisher_;
    rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr subscriber_;
    rclcpp::TimerBase::SharedPtr timer_, timer_serial;
};

// 更新里程计（核心逻辑不变，仅用统一弧度制）
void QinbotOdom::update_odom(double dt)
{
    double dt_s = dt;
    // 直接用转换后的弧度制Yaw角作为姿态（无积分误差）
    odom.angle = Yaw_angle;
    TransAngleInPI(odom.angle, odom.angle);

    // 正确计算角速度：角度变化量 / 时间差（弧度制）
    angular_speed = (odom.angle - last_Yaw_angle) / dt_s;
    // 手动限制角速度范围在 [-5.0f, 5.0f]，避免Yaw角跳变导致异常
    if (angular_speed > 5.0f) angular_speed = 5.0f;
    else if (angular_speed < -5.0f) angular_speed = -5.0f;

    // 位置积分（逻辑正确，弧度制计算）
    double delta_distance = odom.linear_speed * dt_s;
    odom.x += delta_distance * std::cos(odom.angle);
    odom.y += delta_distance * std::sin(odom.angle);

    // 更新上一帧Yaw角
    last_Yaw_angle = odom.angle;
}

// 角度归一化（弧度制，-PI~PI）
void QinbotOdom::TransAngleInPI(float angle, float& out_angle)
{
    out_angle = angle;
    while (out_angle > PI) out_angle -= 2 * PI;
    while (out_angle < -PI) out_angle += 2 * PI;
}

// 发布odom（逻辑不变）
void QinbotOdom::timer_callback()
{
    // rclcpp::Time hardware_time = this->get_clock()->now();
    // rclcpp::Duration offset = rclcpp::Duration::from_seconds(52.0);
    // rclcpp::Time calibrated_time = hardware_time - offset;
    
    
    rclcpp::Time current_time = this->get_clock()->now();
    double dt = (current_time  - last_time_).seconds();
    
    if (dt < 0 || dt > 0.5) dt = 0.1;

    update_odom(dt);
    last_time_ = current_time ;

    odom_msg.header.stamp = current_time ;
    odom_msg.header.frame_id = "odom";
    //odom_msg.child_frame_id = "base_link";
    odom_msg.child_frame_id = "base_footprint";
    
    odom_msg.pose.pose.position.x = odom.x;
    odom_msg.pose.pose.position.y = odom.y;
    odom_msg.pose.pose.position.z = 0.0;

    // 姿态四元数（基于弧度制Yaw角）
    odom_msg.pose.pose.orientation.w = cos(odom.angle * 0.5);
    odom_msg.pose.pose.orientation.x = 0.0;
    odom_msg.pose.pose.orientation.y = 0.0;
    odom_msg.pose.pose.orientation.z = sin(odom.angle * 0.5);

    // 速度信息
    odom_msg.twist.twist.linear.x = odom.linear_speed;
    odom_msg.twist.twist.linear.y = 0.0;
    odom_msg.twist.twist.linear.z = 0.0;
    odom_msg.twist.twist.angular.x = 0.0;
    odom_msg.twist.twist.angular.y = 0.0;
    odom_msg.twist.twist.angular.z = angular_speed;

    publisher_->publish(odom_msg);
}

// 串口读取（逻辑不变）
void QinbotOdom::timer_serialcallback()
{
    if(!read_char(&serial_odom, &recv_c))
    {
        if(recv_c == 's')
        {
            rev_flag = 1;
            rev_count = 0;
            encoder_list[rev_count] = 's';
        }
        else if(rev_flag == 1)
        {
            rev_count++;
            if(rev_count >= ODOMDATA_NUM)
            {
                rev_flag = 0;
                rev_count = 0;
                success_flag = 0;
            }
            else
            {
                encoder_list[rev_count] = recv_c;
                if(rev_count == (ODOMDATA_NUM - 1) && encoder_list[ODOMDATA_NUM - 1] == 'e')
                {
                    success_flag = 1;
                    odom_process(encoder_list);
                    rev_flag = 0;
                    rev_count = 0;
                    timer_callback();
                }
            }
        }
    }
}

// 数据解析（核心修正：角度制Yaw角转弧度制）
void QinbotOdom::odom_process(unsigned char serial_list[])
{
    // 1. 左右轮脉冲解析（逻辑不变，保留）
    LF_flag = serial_list[1];
    int L_pulse = serial_list[2]; // 左轮10ms平均脉冲数（单片机已合并同侧两轮）
    if(LF_flag == '+')
    {
        encoder_L += L_pulse;
        speed_L = L_pulse * PULSE_SPEED;
    }
    else
    {   
        encoder_L -= L_pulse;
        speed_L = -L_pulse * PULSE_SPEED;
    }

    RF_flag = serial_list[3];
    int R_pulse = serial_list[4]; // 右轮10ms平均脉冲数（单片机已合并同侧两轮）
    if(RF_flag == '+')
    {
        encoder_R += R_pulse;
        speed_R = R_pulse * PULSE_SPEED;
    }
    else
    {
        encoder_R -= R_pulse;
        speed_R = -R_pulse * PULSE_SPEED;
    }

    // 2. Yaw角解析（核心修正：角度制→弧度制，直接赋值绝对角度）
    Yaw_flag = serial_list[5];
    // 解析整数部分（-180~180）和小数部分（0~99，假设serial_list[7]是0~99，对应0.00~0.99°）
    int Yaw_int = static_cast<int>(serial_list[6]);    // 整数部分（比如180、-90，注意符号）
    int Yaw_dec = static_cast<int>(serial_list[7]);    // 小数部分（比如50→0.50°）
    float yaw_angle_deg = Yaw_int + (Yaw_dec / 100.0f); // 组合为角度制（例：180.50°）
    //float yaw_angle_deg = Yaw_int; // 组合为角度制（例：180.50°）

    // 符号位修正（如果Yaw_int本身带符号，这里只需根据Yaw_flag确认，避免双重符号）
    if(Yaw_flag == '-')
    {
        yaw_angle_deg = -yaw_angle_deg;
    }

    // 关键：角度制转弧度制（内部统一用弧度制计算）
    Yaw_angle = yaw_angle_deg * ANGLE_TO_RAD;

    // 3. 运动学正解（逻辑不变）
    linear_speed = (speed_L + speed_R) / 2.0f;
    odom.linear_speed = linear_speed;

    // 可选：打印调试（确认解析和转换正确）
    //RCLCPP_INFO(this->get_logger(), "Yaw(deg): %.2f → Yaw(rad): %.3f, 线速度: %.3f m/s",
    //            yaw_angle_deg, Yaw_angle, linear_speed);
}

// 发送cmd_vel（补全之前没写完的代码，避免数组越界）
void QinbotOdom::vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg)
{
    RCLCPP_INFO(this->get_logger(), "收到速度信息：线速度x=%.2f, 角速度z=%.2f",
                msg->linear.x, msg->angular.z);

    float linear_x = msg->linear.x;
    char linear_sign = (linear_x >= 0) ? '+' : '-';
    int linear_raw = static_cast<int>(round(fabs(linear_x) * 100));
    linear_raw %= 10000;

    float angular_z = msg->angular.z;
    char angular_sign = (angular_z >= 0) ? '+' : '-';
    int angular_raw = static_cast<int>(round(fabs(angular_z) * 100));
    angular_raw %= 10000;

    // 填充14字节数据包（完整补全）
    serial_data[0] = 's';                   // 起始标识
    serial_data[1] = 'l';                   // 线速度标识
    serial_data[2] = linear_sign;           // 线速度符号
    serial_data[3] = static_cast<char>((linear_raw / 100) / 10 % 10 + '0'); // 线速度十位
    serial_data[4] = static_cast<char>((linear_raw / 100) % 10 + '0');      // 线速度个位
    serial_data[5] = static_cast<char>((linear_raw / 10) % 10 + '0');       // 线速度小数第一位
    serial_data[6] = static_cast<char>(linear_raw % 10 + '0');              // 线速度小数第二位
    serial_data[7] = 'a';                   // 角速度标识
    serial_data[8] = angular_sign;          // 角速度符号
    serial_data[9] = static_cast<char>((angular_raw / 100) / 10 % 10 + '0');// 角速度十位
    serial_data[10] = static_cast<char>((angular_raw / 100) % 10 + '0');     // 角速度个位
    serial_data[11] = static_cast<char>((angular_raw / 10) % 10 + '0');      // 角速度小数第一位
    serial_data[12] = static_cast<char>(angular_raw % 10 + '0');             // 角速度小数第二位
    serial_data[13] = 'e';                  // 结束标识

    send_strdata(&serial_odom, serial_data, 14);  // 发送14字节数据
}

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    serial_odom.port = SERIAL_PORT;
    serial_odom.baud_rate = BAUD_RATE;
    serial_odom.timeout = TIMEOUT;
    if (open_serial(&serial_odom) != 0) {
        std::cerr << "串口初始化失败" << std::endl;
        return -1;
    }
    rclcpp::spin(std::make_shared<QinbotOdom>());
    rclcpp::shutdown();
    close_serial(&serial_odom);
    return 0;
}
