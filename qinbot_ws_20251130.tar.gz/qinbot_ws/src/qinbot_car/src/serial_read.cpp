
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <string.h>
#include <sys/ioctl.h>
#include "serial_comm.h"

//根据具体的设备修改

// int main() {
//     // 初始化串口参数（根据实际硬件修改）
//     SerialComm serial = {
//         -1,
//         "/dev/ttyS3",
//         B115200,
//         2000
//     };

//     // 打开串口
//     if (open_serial(&serial) != 0) {
//         std::cerr << "串口初始化失败" << std::endl;
//         return -1;
//     }

//     // 循环接收字符（测试接收功能）
//     unsigned char recv_c;
//     printf("等待接收数据（超时2秒）...\n");
//     while (1) 
//     {
//         int ret = read_char(&serial, &recv_c);
//         if (ret == 0) 
//         {
//             // 成功接收：打印字符（区分可打印字符和十六进制）
//             if (isprint(recv_c)) 
//             {
//                 printf("收到可打印字符：'%c'（ASCII：%d）\n", recv_c, recv_c);
//             } else 
//             {
//                 printf("收到非可打印字符：0x%02X\n", recv_c);
//             }
//         }
//     }

//     // 关闭串口
//     close_serial(&serial);
//     return 0;
// }

// 创建串口通信对象
SerialComm serialComm;
int main()
{
    serialComm.port = SERIAL_PORT;
    serialComm.baud_rate = BAUD_RATE;
    serialComm.timeout = 2000;
    unsigned char recv_c;
    // 打开串口
    if (open_serial(&serialComm) != 0) {
        std::cerr << "串口初始化失败" << std::endl;
        return -1;  // 串口打开失败，退出程序
    }
    while(1)
    {
        if(!read_char(&serialComm, &recv_c))
            printf("收到字符：'%d'\n", recv_c);
    }

    close_serial(&serialComm);
}