#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <iostream>
#include <vector>
#include <errno.h>
#include <map>
#include <linux/input.h>
#include <cstdlib>
#include "gamepadreader.h"

const int STATE_RESET = 0;
const int STATE_LEFT = 30;
const int STATE_RIGHT = 32;
const int STATE_UP = 17;
const int STATE_DOWN = 31;
const int STATE_LEFT_TURN = 16;
const int STATE_RIGHT_TURN = 18;
const int STATE_SPEED = 33;


GamepadReader::GamepadReader(const std::string& device_path)
    : device_path_(device_path), device_fd_(-1), axes(8, 0) {
    // 初始化map_结构
    map_.lx = 0;
    map_.ly = 0;
    map_.rx = 0;
    map_.ry = 0;
    map_.b = 0;
}

GamepadReader::~GamepadReader() {
    if (device_fd_ != -1) {
        closeDevice();
    }
}

bool GamepadReader::hasNewEvent() {
    fd_set fds;
    struct timeval tv;
    FD_ZERO(&fds);
    FD_SET(device_fd_, &fds);
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    return select(device_fd_ + 1, &fds, NULL, NULL, &tv) > 0;
}

void GamepadReader::updateMap(const js_event& js) {
    if (js.type & JS_EVENT_AXIS) {
        switch(js.number) {
            case 0: map_.lx = js.value; break;
            case 1: map_.ly = js.value; break;
            case 3: map_.rx = js.value; break;
            case 4: map_.ry = js.value; break;
        }
    }
    else if (js.type & JS_EVENT_BUTTON) {
        switch(js.number) {
            case 0: map_.a = js.value; break; // A按键
            case 1: map_.b = js.value; break; // B按键
            case 2: map_.x = js.value; break; // X按键
            case 3: map_.y = js.value; break; // Y按键
        }
    }
}

bool GamepadReader::readNextEvent() {
    if (device_fd_ == -1) return false;
    
    struct js_event js;
    ssize_t bytes = read(device_fd_, &js, sizeof(js));
    if (bytes == sizeof(js)) {
        updateMap(js);
        return true;
    }
    return false;
}

std::vector<int> GamepadReader::returnStickState() {
    std::vector<int> states;
    
    // 只读取一次最新状态
    if (hasNewEvent()) {
        readNextEvent();
    }

    if((-16384 > map_.lx) && (std::abs(map_.ly) < 16384)) {
        states.push_back(STATE_LEFT);
    }
    else if((16384 < map_.lx) && (std::abs(map_.ly) < 16384)) {
        states.push_back(STATE_RIGHT);
    }
    else if((std::abs(map_.lx) < 16384) && (-16384 > map_.ly)) {
        states.push_back(STATE_UP);
    }
    else if((std::abs(map_.lx) < 16384) && (16384 < map_.ly)) {
        states.push_back(STATE_DOWN);
    }
    else if((-16384 > map_.rx) && (std::abs(map_.ry) < 16384)) {
        states.push_back(STATE_LEFT_TURN);
    }
    else if((16384 < map_.rx) && (std::abs(map_.ry) < 16384)) {
        states.push_back(STATE_RIGHT_TURN);
    }
    else if(map_.b){
        states.push_back(STATE_SPEED);
    }
    else{
        states.push_back(STATE_RESET);
    }
    return states;
}

std::string GamepadReader::getPadState() {
    std::string state;
    std::vector<int> states = returnStickState();
    
    if (!states.empty()) {
        for (int s : states) {
            switch(s) {
                case STATE_RESET: state = "reset"; break;
                case STATE_LEFT: state = "left"; break;
                case STATE_RIGHT: state = "right"; break;
                case STATE_UP: state = "up"; break;
                case STATE_DOWN: state = "down"; break;
                case STATE_LEFT_TURN: state = "left_turn"; break;
                case STATE_RIGHT_TURN: state = "right_turn"; break;
            }
        }
    }
    return state;
}

int GamepadReader::getAxisValue(int axis) {
    if (axis >= 0 && axis < axes.size()) {
        return axes[axis];
    }
    return 0;
}

void GamepadReader::closeDevice() {
    if (device_fd_ != -1) {
        close(device_fd_);
        device_fd_ = -1;
    }
}
