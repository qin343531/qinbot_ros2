#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTcpServer>
#include <QTcpSocket>
#include <QHostAddress>
#include <QDebug>
#include <QNetworkInterface>
#include <QImage>
#include <QPixmap>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    video_server(new QTcpServer(this)),
    message_server(new QTcpServer(this)),
    reader(""),
    isCapturing(false),
    rtspCamera(),
    camVideoWriter(),
    irVideoWriter()
{
    // 初始化UI和服务但不显示窗口
    ui->setupUi(this);
    setWindowTitle("红外智能巡检车");
    initializeServices();
    setWindowState(Qt::WindowMinimized);
    setVisible(false);
    
    // 延迟创建并启动启动动画
    QTimer::singleShot(100, this, [this]() {
        splash = new SplashScreen();
        splash->setImage("/home/qin/qt_project/IRCar_RTSP_MENU_UI/panda.png");
        connect(splash, &SplashScreen::animationFinished,
                this, &MainWindow::showMainWindow,
                Qt::QueuedConnection);
        splash->startAnimation();
    });

    //m702传感器
//    m702_timer->setInterval(1);
//    connect(m702_timer, &QTimer::timeout, this, &MainWindow::m702_timeout);
//    qDebug() << "多模块传感器测试程序";
//    m702_fd = m702_dev.open_m702dev();

//    m702_timer->start();
}

void MainWindow::initializeServices()
{
    // 指定视频服务器的IP地址为192.168.1.2，监听端口12345
    QHostAddress serverIp("192.168.1.15");
    if (video_server->listen(serverIp, 12345)) {
        connect(video_server, &QTcpServer::newConnection,
                this, &MainWindow::newVideoClient);
    }

    // 指定按键数据服务器
    if (message_server->listen(serverIp, 12346)) {
        connect(message_server, &QTcpServer::newConnection,
                this, &MainWindow::newMessageClient);
    }

    // ===== 修复游戏手柄初始化逻辑 =====
//    key_statue = false;
//    stopReading = true; // 初始化为停止读取，避免空指针
//    timer = new QTimer(this); // 提前初始化timer，避免空指针
//    connect(timer, &QTimer::timeout, this, &MainWindow::readKey);

    // 检查设备文件是否存在
//    QFile deviceFile("/dev/input/js0");
//    if (deviceFile.exists()) {
//        if (reader.openDevice()) {
//            ui->textEdit->append("游戏手柄设备 /dev/input/js0 打开成功！");
//            stopReading = false; // 仅当设备打开成功时允许读取
//        } else {
//            ui->textEdit->append("警告：游戏手柄设备存在，但打开失败！");
//        }
//    } else {
//        // 设备不存在时给出提示，不终止程序
//        ui->textEdit->append("警告：未找到游戏手柄设备 /dev/input/js0，按键监控功能不可用！");
//    }

    // 初始化红外定时器（原有逻辑保留）
    ir_timer = new QTimer(this);
    connect(ir_timer, &QTimer::timeout, this, &MainWindow::updateImage);

    // 初始化相机
    rtspCamera.stopCapture();

    QString displayText;
    displayText += "二氧化碳(CO₂)：0 ppm\n";
    displayText += "甲醛(HCHO)：0 ppb\n";
    displayText += "总挥发性有机物(TVOC)：0 ppb\n";
    displayText += "PM2.5：0 μg/m³\n";
    displayText += "PM10：0 μg/m³\n";
    displayText += "温度：0.00 ℃\n";
    displayText += "湿度：0.00 %RH\n";

    // 程序启动时就显示默认值到textEdit_m702
    ui->textEdit_m702->setText(displayText);

}

void MainWindow::showMainWindow()
{
    // 确保启动动画被清理
    if (splash) {
        splash->hide();
        splash->deleteLater();
        splash = nullptr;
    }
    
    // 设置窗口状态并显示
    setWindowState(Qt::WindowActive);
    setVisible(true);
    activateWindow();
    raise();
    
    // 显示日志信息
    ui->textEdit->append("服务器启动中...");
    QHostAddress serverIp("192.168.1.15");
    if (video_server->isListening()) {
        qDebug() << "视频服务器启动成功，监听端口 12345";
        ui->textEdit->append("视频服务器启动成功，监听端口 12345");
    } else {
        qDebug() << "视频服务器启动失败：" << video_server->errorString();
        ui->textEdit->append("视频服务器启动失败！");
    }

    if (message_server->isListening()) {
        qDebug() << "传感器数据服务器启动成功，监听端口 12346";
        ui->textEdit->append("传感器数据服务器启动成功，监听端口 12346");
    } else {
        qDebug() << "传感器数据服务器启动失败：" << message_server->errorString();
        ui->textEdit->append("传感器数据服务器启动失败！");
    }
}

MainWindow::~MainWindow()
{
    delete ui;  // 释放 ui 内存
    video_server->deleteLater();
    message_server->deleteLater();
    rtspCamera.stopCapture();
}

// 视频客户端连接处理
void MainWindow::newVideoClient()
{
    // 获取新的视频客户端连接
    QTcpSocket *clientSocket = video_server->nextPendingConnection();

    // 获取客户端 IP 和端口
    QString clientIp = clientSocket->peerAddress().toString();
    qint16 clientPort = clientSocket->peerPort();

    // 输出客户端的 IP 地址
    ui->textEdit->append(QString("视频客户端连接: %1:%2").arg(clientIp).arg(clientPort));

    // 连接读取数据的信号
    connect(clientSocket, &QTcpSocket::readyRead, this, &MainWindow::readVideoData);

    // 保存视频客户端 socket 以便后续使用
    videoClientSockets.append(clientSocket);
}

void MainWindow::newMessageClient()
{
    QTcpSocket *clientSocket = message_server->nextPendingConnection();
    if (!clientSocket) return;

    QString clientIp = clientSocket->peerAddress().toString();
    qint16 clientPort = clientSocket->peerPort();

    ui->textEdit->append(QString("传感器数据客户端连接: %1:%2").arg(clientIp).arg(clientPort));

    // 连接读取数据的信号
    connect(clientSocket, &QTcpSocket::readyRead, this, &MainWindow::readAirsensorData);

    // 保存 socket
    messageClientSockets.append(clientSocket);
}


// 读取视频数据
void MainWindow::readVideoData()
{
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket *>(sender());
    if (clientSocket && isSending)
    {
        static qint64 expectedImageSize = 0;
        static QByteArray imageDataBuffer;

        if (expectedImageSize == 0)
        {
            QByteArray sizeData = clientSocket->read(sizeof(expectedImageSize));
            if (sizeData.size() == sizeof(expectedImageSize))
            {
                memcpy(&expectedImageSize, sizeData.data(), sizeof(expectedImageSize));
            }
            else
            {
                return;
            }
        }

        QByteArray imageData = clientSocket->read(expectedImageSize - imageDataBuffer.size());
        imageDataBuffer.append(imageData);

        if (imageDataBuffer.size() >= expectedImageSize)
        {
            // 保存原始图像数据
            std::lock_guard<std::mutex> lock(m_frameMutex);
            m_currentImageData = imageDataBuffer;  // 保存原始数据流

            // 仅用于显示的处理
            std::vector<uchar> buffer(imageDataBuffer.begin(), imageDataBuffer.end());
            cv::Mat frame = cv::imdecode(buffer, cv::IMREAD_COLOR);
            if (!frame.empty()) {
                cv::cvtColor(frame, frame, cv::COLOR_BGR2RGB);  // BGR转RGB
                QImage image(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
                ui->CamLabel->setPixmap(QPixmap::fromImage(image).scaled(ui->CamLabel->size(), Qt::KeepAspectRatio));
            }

            imageDataBuffer.clear();
            expectedImageSize = 0;
        }
    }
}



// 发送消息到所有客户端
void MainWindow::sendMessageToClients(const QByteArray &message)
{
    for (QTcpSocket *clientSocket : messageClientSockets) {
        clientSocket->write(message);
    }
}

// 获取服务器的 IP 地址
QString MainWindow::getLocalIpAddress()
{
    QString ipAddress;
    QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();

    foreach (QNetworkInterface interface, interfaces) {
        if (interface.name() == "enp2s0") {
            QList<QNetworkAddressEntry> entryList = interface.addressEntries();
            foreach (QNetworkAddressEntry entry, entryList) {
                if (!entry.ip().toString().contains("127.0.") && !entry.ip().toString().isEmpty()) {
                    ipAddress = entry.ip().toString();
                    break;
                }
            }
        }
        if (!ipAddress.isEmpty()) {
            break;  // 找到有效的 IP 后就退出循环
        }
    }

    return ipAddress.isEmpty() ? "未找到有效的 IP 地址" : ipAddress;
}

QTcpSocket* MainWindow::getClientSocket()
{
    if (!messageClientSockets.isEmpty()) {
        return messageClientSockets.first();  // 获取第一个按键数据客户端连接
    }
    return nullptr;  // 如果没有连接，返回 nullptr
}

void MainWindow::readAirsensorData()
{
    // 从sender()获取当前触发信号的客户端socket
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket *>(sender());
    if (clientSocket)
    {
        // 读取所有可用的传感器数据
        QByteArray sensorData = clientSocket->readAll();
        if (!sensorData.isEmpty())
        {
            // 转换为UTF-8字符串（避免乱码）
            QString sensorStr = QString::fromUtf8(sensorData);

            // ========== 核心修改：拆分数据并分行显示 ==========
            QString displayText;

            // 按逗号拆分原始字符串
            QStringList parts = sensorStr.split(", ");
            for (const QString& part : parts)
            {
                // 按冒号拆分键值对
                QStringList keyValue = part.split(": ");
                if (keyValue.size() == 2)
                {
                    QString key = keyValue[0];
                    QString value = keyValue[1];

                    // 给不同参数添加单位，分行显示
                    if (key == "eco2") {
                        displayText += QString("二氧化碳(CO₂)：%1 ppm\n").arg(value);
                    } else if (key == "ech2o") {
                        displayText += QString("甲醛(HCHO)：%1 ppb\n").arg(value);
                    } else if (key == "tvoc") {
                        displayText += QString("总挥发性有机物(TVOC)：%1 ppb\n").arg(value);
                    } else if (key == "pm25") {
                        displayText += QString("PM2.5：%1 μg/m³\n").arg(value);
                    } else if (key == "pm10") {
                        displayText += QString("PM10：%1 μg/m³\n").arg(value);
                    } else if (key == "temperature") {
                        // 保留2位小数显示温度
                        displayText += QString("温度：%1 ℃\n").arg(value.toFloat(), 0, 'f', 2);
                    } else if (key == "humidity") {
                        // 保留2位小数显示湿度
                        displayText += QString("湿度：%1 %RH\n").arg(value.toFloat(), 0, 'f', 2);
                    } else {
                        displayText += QString("%1：%2\n").arg(key).arg(value);
                    }
                }
            }

            // 覆盖显示格式化后的内容到textEdit_m702
            ui->textEdit_m702->setText(displayText);

            // 调试输出
            //qInfo() << "✅ 收到传感器数据（格式化后）：\n" << displayText;
            //ui->textEdit->append("收到传感器数据：" + sensorStr); // 原始数据显示到日志框
        }
    }
}


void MainWindow::on_IRButton_clicked()
{
    // 判断是否连接到红外摄像头
    if (!rtspCamera.isConnect()) {
        ui->textEdit->append("红外摄像头未连接！");
        return;
    }

    if (isCapturing) {
        // 停止捕获
        ir_timer->stop();
        rtspCamera.stopCapture();  // 停止捕获红外图像
        isCapturing = false;
        ui->IRButton->setText("开始接收");
        ui->textEdit->append("停止显示图像");
    } else {
        // 开始捕获
        ir_timer->start(10);  // 每 10 毫秒更新一次图像
        rtspCamera.startCapture();  // 开始捕获红外图像
        isCapturing = true;
        ui->IRButton->setText("停止接收");
        ui->textEdit->append("开始显示图像");
    }
}

void MainWindow::on_gameboxButton_clicked()
{
    // 检查设备是否可用
    if (!reader.isDeviceOpen()) {
        ui->textEdit->append("错误：游戏手柄设备未连接，无法启动按键监控！");
        return;
    }

    key_statue = !key_statue;
    if (key_statue) {
        stopReading = false;  // 开始读取
        timer->start(20);     // 降低频率，减少资源占用（5ms→20ms）
        ui->textEdit->append("按键监控已启动");
        qDebug() << "Key Monitoring Started";
    } else {
        timer->stop();        // 停止定时器
        stopReading = true;   // 停止读取按键
        ui->textEdit->append("按键监控已停止");
        qDebug() << "Key Monitoring Stopped";
    }
}

void MainWindow::updateImage()
{
    cv::Mat frame = rtspCamera.getFrame();
    if (frame.empty()) {
        return;
    }

    // 首先保存原始帧
    {
        std::lock_guard<std::mutex> lock(m_frameMutex);
        m_currentIRFrame = frame.clone();
    }

    // 仅用于显示
    QImage qImage;
    if (frame.channels() == 1) {
        qImage = QImage(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_Grayscale8).copy();
    } else {
        cv::Mat grayFrame;
        cv::cvtColor(frame, grayFrame, cv::COLOR_BGR2GRAY);
        qImage = QImage(grayFrame.data, grayFrame.cols, grayFrame.rows, grayFrame.step, QImage::Format_Grayscale8).copy();
    }

    if (!qImage.isNull()) {
        ui->IRLabel->setPixmap(QPixmap::fromImage(qImage).scaled(ui->IRLabel->size(), Qt::KeepAspectRatio));
    }
}

void MainWindow::on_CamButton_clicked()
{
    isSending = !isSending;  // 切换状态
    ui->CamButton->setText(isSending ? "停止接收" : "开始接收");
}

//录制可见光图像
void MainWindow::recordCamImage(const QString &timestamp)
{
    if (!isSending) {
        ui->textEdit->append("可见光摄像头未连接！");
        return;
    }

    if (!m_isRecordingCam) {
        m_isRecordingCam = true;
        ui->textEdit->append("开始录制可见光视频...");

        std::lock_guard<std::mutex> lock(m_frameMutex);
        if (!m_currentImageData.isEmpty()) {
            std::vector<uchar> buffer(m_currentImageData.begin(), m_currentImageData.end());
            cv::Mat firstFrame = cv::imdecode(buffer, cv::IMREAD_COLOR);  // 解码为BGR格式

            if (!firstFrame.empty()) {
                QString videoPath = QString("/home/qin/qt_project/IRCar_RTSP_MENU_UI/videos/Cam_%1.avi").arg(timestamp);

                // 直接使用BGR格式的frame，无需转换
                camVideoWriter.open(videoPath.toStdString(),
                                  cv::VideoWriter::fourcc('M','J','P','G'),
                                  30,
                                  firstFrame.size(),
                                  true);

                if (!camVideoWriter.isOpened()) {
                    ui->textEdit->append("无法初始化可见光视频录制！");
                    m_isRecordingCam = false;
                    return;
                }

                if (!recordTimer) {
                    recordTimer = new QTimer(this);
                    connect(recordTimer, &QTimer::timeout, this, [this]() {
                        std::lock_guard<std::mutex> lock(m_frameMutex);
                        if (m_isRecordingCam && !m_currentImageData.isEmpty()) {
                            // 从原始数据流解码并写入视频
                            std::vector<uchar> buffer(m_currentImageData.begin(), m_currentImageData.end());
                            cv::Mat frame = cv::imdecode(buffer, cv::IMREAD_COLOR);  // 直接解码为BGR格式
                            if (!frame.empty()) {
                                camVideoWriter.write(frame);  // 直接写入BGR格式的frame
                            }
                        }
                    });
                }
                recordTimer->start(33);  // ~30fps
            } else {
                ui->textEdit->append("无法初始化视频帧！");
                m_isRecordingCam = false;
            }
        } else {
            ui->textEdit->append("没有可用的视频数据！");
            m_isRecordingCam = false;
        }
    } else {
        m_isRecordingCam = false;
        recordTimer->stop();
        camVideoWriter.release();
        ui->textEdit->append("可见光视频录制已完成！");
    }
}

//录制红外视频
void MainWindow::recordIRImage(const QString &timestamp)
{
    if (!rtspCamera.isConnect()) {
        ui->textEdit->append("红外摄像头未连接！");
        return;
    }

    if (!m_isRecordingIR) {
        m_isRecordingIR = true;
        ui->textEdit->append("开始录制红外视频...");

        std::lock_guard<std::mutex> lock(m_frameMutex);
        if (!m_currentIRFrame.empty()) {
            QString videoPath = QString("/home/qin/qt_project/IRCar_RTSP_MENU_UI/videos/IR_%1.avi").arg(timestamp);
            irVideoWriter.open(videoPath.toStdString(),
                             cv::VideoWriter::fourcc('M','P','N','G'),  // 使用MPNG编码
                             30,
                             m_currentIRFrame.size(),
                             false);  // 设置为false表示灰度视频

            if (!irVideoWriter.isOpened()) {
                ui->textEdit->append("无法初始化红外视频录制！");
                m_isRecordingIR = false;
                return;
            }

            if (!recordTimer) {
                recordTimer = new QTimer(this);
                connect(recordTimer, &QTimer::timeout, this, [this]() {
                    std::lock_guard<std::mutex> lock(m_frameMutex);
                    if (m_isRecordingIR && !m_currentIRFrame.empty()) {
                        irVideoWriter.write(m_currentIRFrame);
                    }
                });
            }
            recordTimer->start(33);
        }
    } else {
        m_isRecordingIR = false;
        recordTimer->stop();
        irVideoWriter.release();
        ui->textEdit->append("红外视频录制已完成！");
    }
}

//录制可见光
void MainWindow::on_recordCamButton_clicked()
{
    // 获取当前时间，格式为 "yyyyMMdd_HHmmss"
    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");
    recordCamImage(timestamp);  // 传递时间戳
}

//录制红外
void MainWindow::on_recordIRButton_clicked()
{
    // 获取当前时间，格式为 "yyyyMMdd_HHmmss"
    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");
    recordIRImage(timestamp);  // 传递时间戳
}

//保存可见光图像
void MainWindow::on_saveCamButton_clicked()
{
    if (!isSending) {
        ui->textEdit->append("可见光摄像头未连接！");
        return;
    }

    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");
    QString imagePath = QString("/home/qin/qt_project/IRCar_RTSP_MENU_UI/images/Cam_%1.png").arg(timestamp);

    std::lock_guard<std::mutex> lock(m_frameMutex);
    if (!m_currentImageData.isEmpty()) {
        // 将原始数据流转换为图像并保存
        std::vector<uchar> buffer(m_currentImageData.begin(), m_currentImageData.end());
        cv::Mat frame = cv::imdecode(buffer, cv::IMREAD_COLOR);
        if (!frame.empty()) {
            std::vector<int> compression_params;
            compression_params.push_back(cv::IMWRITE_PNG_COMPRESSION);
            compression_params.push_back(9);  // PNG压缩级别设为最高(0-9)

            if (cv::imwrite(imagePath.toStdString(), frame, compression_params)) {
                ui->textEdit->append(QString("可见光图像已保存: %1 (分辨率: %2x%3)").arg(
                    imagePath).arg(frame.cols).arg(frame.rows));
            } else {
                ui->textEdit->append("保存可见光图像失败！");
            }
        } else {
            ui->textEdit->append("图像解码失败！");
        }
    } else {
        ui->textEdit->append("没有可用的可见光图像数据！");
    }
}

//保存红外图像
void MainWindow::on_saveIRButton_clicked()
{
    if (!rtspCamera.isConnect()) {
        ui->textEdit->append("红外摄像头未连接！");
        return;
    }

    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");
    QString imagePath = QString("/home/qin/qt_project/IRCar_RTSP_MENU_UI/images/IR_%1.png").arg(timestamp);

    std::lock_guard<std::mutex> lock(m_frameMutex);
    if (!m_currentIRFrame.empty()) {
        if (cv::imwrite(imagePath.toStdString(), m_currentIRFrame)) {
            ui->textEdit->append("红外图像已保存: " + imagePath);
        } else {
            ui->textEdit->append("保存红外图像失败！");
        }
    } else {
        ui->textEdit->append("没有可用的红外图像数据！");
    }
}

