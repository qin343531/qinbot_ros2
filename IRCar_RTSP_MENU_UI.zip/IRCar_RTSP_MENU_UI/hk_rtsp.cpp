#include "hk_rtsp.h"
#include <iostream>

namespace hk {

RtspCamera::RtspCamera()
    : m_userId(-1), m_realPlayHandle(-1), m_isRunning(false),
      m_frameCount(0), m_fps(0.0), m_fpsUpdateInterval(1) {
    NET_DVR_Init();
    NET_DVR_SetConnectTime(2000, 1);
    NET_DVR_SetReconnect(10000, true);
    m_lastCallbackTime = std::chrono::steady_clock::now();
}

RtspCamera::~RtspCamera() {
    stopCapture();
    NET_DVR_Cleanup();
}

bool RtspCamera::initializeCamera() {
    NET_DVR_USER_LOGIN_INFO struLoginInfo = {0};
    strcpy(struLoginInfo.sDeviceAddress, "192.168.1.64");
    struLoginInfo.wPort = 8000;
    strcpy(struLoginInfo.sUserName, "admin");
    strcpy(struLoginInfo.sPassword, "JIQIREN1234");

    NET_DVR_DEVICEINFO_V40 struDeviceInfoV40 = {0};
    m_userId = NET_DVR_Login_V40(&struLoginInfo, &struDeviceInfoV40);

    if (m_userId < 0) {
        std::cout << "登录失败，错误码: " << NET_DVR_GetLastError() << std::endl;
        return false;
    }

    // 直接设置RTSP取流
    cv::VideoCapture cap;
    std::string rtspUrl = getRtspUrl();
    std::cout << "正在连接RTSP流: " << rtspUrl << std::endl;

    cap.open(rtspUrl);
    if (!cap.isOpened()) {
        std::cout << "RTSP流打开失败" << std::endl;
        NET_DVR_Logout(m_userId);
        return false;
    }

    m_cap = std::move(cap);
    return true;
}

void RtspCamera::startCapture() {
    if (!initializeCamera()) {
        return;
    }

    // 配置RTSP相关参数
    NET_DVR_PREVIEWINFO struPlayInfo = {0};
    struPlayInfo.hPlayWnd = 0;  // 使用0代替NULL
    struPlayInfo.lChannel = 1;
    struPlayInfo.dwStreamType = 0;  // 主码流
    struPlayInfo.dwLinkMode = 4;    // RTP over RTSP
    struPlayInfo.byVideoCodingType = 0;  // 通用编码数据
    struPlayInfo.bBlocked = 1;

    m_realPlayHandle = NET_DVR_RealPlay_V40(m_userId, &struPlayInfo, streamCallback, this);
    if (m_realPlayHandle < 0) {
        std::cout << "预览失败，错误码: " << NET_DVR_GetLastError() << std::endl;
        NET_DVR_Logout(m_userId);
        return;
    }

    m_isRunning = true;
    m_thread = std::thread(&RtspCamera::streamThread, this);
}

std::string RtspCamera::getRtspUrl() const {
    std::vector<std::string> rtsp_urls = {
        // 标准格式 - 彩色视频流
        "rtsp://admin:JIQIREN1234@192.168.1.64:554/Streaming/Channels/1",        // 主码流 - 彩色
        "rtsp://admin:JIQIREN1234@192.168.1.64:554/Streaming/Channels/1/sub",    // 子码流 - 彩色

        // H264格式
        "rtsp://admin:JIQIREN1234@192.168.1.64:554/h264/ch1/main/av_stream",    // 主码流
        "rtsp://admin:JIQIREN1234@192.168.1.64:554/h264/ch1/sub/av_stream",     // 子码流

        // 热成像通道 - 灰度图像
        "rtsp://admin:JIQIREN1234@192.168.1.64:554/Streaming/Channels/2",        // 热成像主码流
        "rtsp://admin:JIQIREN1234@192.168.1.64:554/Streaming/Channels/2/sub"     // 热成像子码流
    };

    std::cout << "Using RTSP URL: " << rtsp_urls[0] << std::endl;
    return rtsp_urls[0];  // 使用彩色主码流
}

const char* RtspCamera::getRtspStreamType(int streamType) const {
    switch(streamType) {
        case 0: return "/main";  // 主码流
        case 1: return "/sub";   // 子码流
        default: return "/main";
    }
}

void RtspCamera::stopCapture() {
    m_isRunning = false;
    if (m_thread.joinable()) {
        m_thread.join();
    }
    if (m_realPlayHandle >= 0) {
        NET_DVR_StopRealPlay(m_realPlayHandle);
    }
    if (m_userId >= 0) {
        NET_DVR_Logout(m_userId);
    }
}

void CALLBACK RtspCamera::streamCallback(LONG lPlayHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, void* pUser) {
    RtspCamera* camera = static_cast<RtspCamera*>(pUser);
    if (camera && dwDataType == NET_DVR_STREAMDATA) {
        camera->processFrame(pBuffer, dwBufSize);
    }
}

void RtspCamera::processFrame(BYTE *pBuffer, DWORD dwBufSize) {
    if (!pBuffer || dwBufSize == 0) {
        return;
    }

    std::vector<uint8_t> buffer(pBuffer, pBuffer + dwBufSize);
    cv::Mat frame = cv::imdecode(buffer, cv::IMREAD_GRAYSCALE);  // 直接解码为灰度图像

    if (!frame.empty()) {
        cv::Mat processed;
        if (frame.type() == CV_16U) {
            // 如果是16位图像，归一化到8位
            cv::normalize(frame, processed, 0, 255, cv::NORM_MINMAX, CV_8UC1);
        } else {
            processed = frame.clone();
        }

        if (!processed.empty()) {
            std::lock_guard<std::mutex> lock(m_queueMutex);
            if (m_frameQueue.size() >= MAX_QUEUE_SIZE) {
                m_frameQueue.pop();
            }
            m_frameQueue.push(processed);
        }
    }
}

cv::Mat RtspCamera::getFrame() {
    std::lock_guard<std::mutex> lock(m_queueMutex);
    if (m_frameQueue.empty()) {
        return cv::Mat();
    }
    // 直接返回最新的帧
    cv::Mat frame = m_frameQueue.front();
    m_frameQueue.pop();
    return frame;
}

void RtspCamera::streamThread() {
    cv::Mat frame;
    while (m_isRunning) {
        if (m_cap.read(frame)) {
            if (!frame.empty()) {
                cv::Mat processed;
                // 保持原始灰度图像
                if (frame.type() == 16) {  // CV_16UC3
                    std::vector<cv::Mat> channels;
                    cv::split(frame, channels);  // 分离通道

                    // 使用第一个通道作为热成像数据
                    cv::Mat grayImage = channels[0];

                    // 归一化到0-255范围
                    cv::normalize(grayImage, processed, 0, 255, cv::NORM_MINMAX, CV_8UC1);

                    // 注释掉颜色映射相关代码，保持灰度图像
                    // cv::applyColorMap(normalized, processed, cv::COLORMAP_JET);
                } else if (frame.channels() > 1) {
                    cv::cvtColor(frame, processed, cv::COLOR_BGR2GRAY);
                } else {
                    processed = frame.clone();
                }

                if (!processed.empty()) {
                    std::lock_guard<std::mutex> lock(m_queueMutex);
                    while (!m_frameQueue.empty()) {
                        m_frameQueue.pop();
                    }
                    m_frameQueue.push(processed);
                }
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }
}

bool RtspCamera::isConnect() {
    // 使用OpenCV尝试打开RTSP流
    cv::VideoCapture temp_cap;
    std::string rtspUrl = getRtspUrl();

    std::cout << "正在检查RTSP连接: " << rtspUrl << std::endl;

    // 尝试打开RTSP流
    if (!temp_cap.open(rtspUrl)) {
        std::cerr << "无法连接到RTSP流" << std::endl;
        return false;
    }

    // 尝试读取一帧，确保流是可用的
    cv::Mat frame;
    bool success = temp_cap.read(frame);
    temp_cap.release();

    return success;
}

} // namespace hk
